package com.focuslock.strict

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/**
 * يرصد التطبيق/الموقع/الشاشة في المقدمة:
 *  - أثناء الوضع الصارم: يحظر التطبيقات والمواقع المختارة، ويحمي شاشات الإعدادات الحساسة بكلمة السر.
 *  - دائماً: يطلب كلمة السر قبل فتح التطبيقات المحمية.
 */
class GuardAccessibilityService : AccessibilityService() {
    private val prefs by lazy { Prefs(this) }
    private var safe: Set<String> = emptySet()
    private var browsers: Set<String> = emptySet()
    // المتصفحات تُراقب تلقائياً، حتى لو ثُبّتت بعد تفعيل الوضع الصارم.
    private var wordBrowsers: Set<String> = emptySet()
    private var refreshedAt = 0L
    private var lastForegroundPkg: String? = null
    private var lastLaunch = 0L
    private var lastSiteCheck = 0L
    private var lastSettingsCheck = 0L

    // ---- حظر الكلمات المفتاحية ----
    private val handler = Handler(Looper.getMainLooper())
    private var overlay: View? = null
    private var lockedPkg: String? = null
    private var pendingKey: String? = null
    private var pendingSince = 0L
    private var scanPending = false
    private var scanDueAt = 0L
    private var matcherWords: Set<String> = emptySet()
    private var matcher = Words.Matcher(emptySet())
    private val scanRunnable = Runnable {
        scanPending = false
        scanDueAt = 0L
        try { checkWords() } catch (_: Throwable) { /* لا نترك الخدمة تنهار */ }
    }

    // لا نعتمد على وصول حدث جديد فقط: افحص النافذة الحالية دورياً، خصوصاً
    // عند تفعيل الوضع الصارم والخدمة متصلة بالفعل أو عند ضياع حدث من النظام.
    private val foregroundPoll = object : Runnable {
        override fun run() {
            try {
                val root = rootInActiveWindow
                val pkg = root?.packageName?.toString()
                if (!pkg.isNullOrBlank()) {
                    val event = AccessibilityEvent.obtain(AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED)
                    event.packageName = pkg
                    try { handle(event) } finally { event.recycle() }
                }
            } catch (_: Throwable) { /* لا نترك الفحص الدوري يُسقط الخدمة */ }
            handler.postDelayed(this, FOREGROUND_POLL_MS)
        }
    }

    companion object {
        private const val FOREGROUND_POLL_MS = 1_000L
    }

    private val sensitiveAll by lazy {
        Guard.SENSITIVE_KEYWORDS +
            listOf("سهولة الوصول", "خيارات المطوّر", "للمطورين", "device manager").map { it.lowercase() } +
            listOf(getString(R.string.app_name), getString(R.string.service_label)).map { it.lowercase() }
    }
    private val devWords by lazy { Guard.DEV_KEYWORDS.map { it.lowercase() }.toSet() }
    private val sensitiveNoDev by lazy { sensitiveAll.filter { it !in devWords } }

    /** خلال أول 72 ساعة من الوضع الصارم لا نحمي شاشة خيارات المطور. */
    private fun sensitive(): List<String> = if (Strict.devGraceActive(prefs)) sensitiveNoDev else sensitiveAll

    override fun onServiceConnected() {
        super.onServiceConnected()
        refresh()
        handler.removeCallbacks(foregroundPoll)
        // افحص التطبيق الظاهر فور اتصال الخدمة، ثم استمر بالفحص كل ثانية.
        foregroundPoll.run()
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacks(scanRunnable)
        handler.removeCallbacks(foregroundPoll)
        hideOverlay()
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        try { handle(event) } catch (_: Throwable) { /* لا نترك الخدمة تنهار أبداً */ }
    }

    private fun refresh() {
        safe = Guard.protectedPackages(this)
        browsers = Guard.browserPackages(this)
        wordBrowsers = Guard.realBrowserPackages(this)
        refreshedAt = SystemClock.elapsedRealtime()
    }

    private fun handle(e: AccessibilityEvent?) {
        val pkg = e?.packageName?.toString() ?: return
        // القفل المؤكد لا يسقط بتبديل النافذة أو فتح الإشعارات أو الشاشة الرئيسية.
        if (lockedPkg != null) {
            if (!prefs.isStrict() || currentMatcher().isEmpty) {
                lockedPkg = null
                pendingKey = null
                hideOverlay()
            } else {
                if (overlay == null) showOverlay()
                return
            }
        }
        if (pkg == packageName) return
        val now = SystemClock.elapsedRealtime()
        val stateChange = e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
        // عند فتح تطبيق جديد نعيد اكتشاف المتصفحات، حتى نلتقط المتصفح المثبّت حديثاً.
        val newForeground = stateChange && pkg != lastForegroundPkg
        if (newForeground) lastForegroundPkg = pkg
        if (now - refreshedAt > 120_000 || (newForeground && pkg !in wordBrowsers)) refresh()
        if (prefs.strictEndAt > 0 && !prefs.isStrict()) Strict.end(this)
        if (pkg in safe) return

        val strict = prefs.isStrict()

        if (strict && inWordScope(pkg)) watchWords(e)

        if (strict && pkg in prefs.blockedApps) { launchBlock(site = false, target = pkg); return }

        if (stateChange && pkg in prefs.lockedApps &&
            (Guard.appGrace[pkg] ?: 0L) < System.currentTimeMillis()
        ) { launchUnlock("app", pkg); return }

        if (!strict) return

        if (pkg in browsers) {
            if (now - lastSiteCheck > 400) { lastSiteCheck = now; checkBrowser(pkg) }
            return
        }
        if (pkg in Guard.SETTINGS) {
            if (System.currentTimeMillis() > prefs.graceUntil && now - lastSettingsCheck > 300) {
                lastSettingsCheck = now
                if ((stateChange && isSensitive(e)) || titleSensitive()) launchUnlock("settings", null)
            }
        }
    }

    /** يقرأ نصوص أعلى الشاشة (العنوان) ويتجاهل صفوف القوائم القابلة للضغط. */
    private fun titleSensitive(): Boolean {
        val root = rootInActiveWindow ?: return false
        if (root.packageName?.toString() !in Guard.SETTINGS) return false
        return scanTitles(root, 0, resources.displayMetrics.heightPixels * 0.30)
    }

    private fun scanTitles(n: AccessibilityNodeInfo?, depth: Int, limit: Double): Boolean {
        if (n == null || depth > 15) return false
        val txt = n.text?.toString()?.lowercase()
        if (!txt.isNullOrEmpty() && !n.isClickable && n.parent?.isClickable != true &&
            n.parent?.parent?.isClickable != true && sensitive().any { txt.contains(it) }
        ) {
            val r = Rect()
            n.getBoundsInScreen(r)
            if (r.top < limit && r.bottom > 0) return true
        }
        for (i in 0 until n.childCount) if (scanTitles(n.getChild(i), depth + 1, limit)) return true
        return false
    }

    private fun isSensitive(e: AccessibilityEvent): Boolean {
        val text = ((e.text?.joinToString(" ") ?: "") + " " + (e.className ?: "")).lowercase()
        return sensitive().any { text.contains(it) }
    }

    private fun checkBrowser(pkg: String) {
        val sites = prefs.blockedSites
        if (sites.isEmpty()) return
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != pkg) return
        val url = findUrl(root, pkg) ?: return
        val host = Guard.normalizeDomain(url) ?: return
        if (Guard.isBlocked(host, sites)) launchBlock(site = true, target = host)
    }

    private fun findUrl(root: AccessibilityNodeInfo, pkg: String): String? {
        Guard.URL_BAR_IDS[pkg]?.forEach { id ->
            val t = root.findAccessibilityNodeInfosByViewId(id).firstOrNull()?.text
            if (!t.isNullOrBlank()) return t.toString()
        }
        return scan(root, 0) // متصفح غير معروف: نبحث عن حقل نص يشبه شريط العنوان
    }

    private fun scan(n: AccessibilityNodeInfo?, depth: Int): String? {
        if (n == null || depth > 12) return null
        val id = n.viewIdResourceName.orEmpty().lowercase()
        val looksLikeBar = n.className?.contains("EditText") == true ||
            id.contains("url") || id.contains("omnibox") || id.contains("address")
        if (looksLikeBar && !n.text.isNullOrBlank()) return n.text.toString()
        for (i in 0 until n.childCount) scan(n.getChild(i), depth + 1)?.let { return it }
        return null
    }

    // ======================= حظر الكلمات المفتاحية =======================

    private fun currentMatcher(): Words.Matcher {
        val w = prefs.blockedWords
        if (w != matcherWords) { matcherWords = w; matcher = Words.Matcher(w) }
        return matcher
    }

    /** كل المتصفحات تُراقب تلقائياً؛ اختيار المستخدم مطلوب للتطبيقات العادية فقط. */
    private fun inWordScope(pkg: String): Boolean = pkg in wordBrowsers || pkg in prefs.keywordApps

    /** فحص سريع لحدث الكتابة، وجدولة فحص كامل عند تغيّر النافذة أو التركيز. */
    private fun watchWords(e: AccessibilityEvent) {
        val m = currentMatcher()
        if (m.isEmpty) return
        when (e.eventType) {
            AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED -> {
                val isField = e.className?.contains("EditText") == true || e.source?.isEditable == true
                // افحص فوراً: الحقول القابلة للتحرير تُعدّ مصدراً قوياً، وبقية النصوص
                // تمر عبر تأكيدين منفصلين داخل checkWords().
                if (isField && !e.isPassword) scheduleScan(0) else scheduleScan(150)
            }
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> scheduleScan(500)
            AccessibilityEvent.TYPE_VIEW_FOCUSED,
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> scheduleScan(150)
        }
    }

    private fun scheduleScan(delayMs: Long) {
        val dueAt = SystemClock.uptimeMillis() + delayMs.coerceAtLeast(0L)
        // Keep the earliest requested scan. A text-edit event (0 ms) must not
        // wait behind an older, slower content-change scan (500 ms).
        if (scanPending && dueAt >= scanDueAt) return
        if (scanPending) handler.removeCallbacks(scanRunnable)
        scanPending = true
        scanDueAt = dueAt
        handler.postAtTime(scanRunnable, dueAt)
    }

    /** قفل ثابت بعد تأكيد الكلمة، مع تأكيد ثانٍ للنصوص غير القابلة للتحرير. */
    private fun checkWords() {
        val m = currentMatcher()
        if (!prefs.isStrict() || m.isEmpty) {
            lockedPkg = null
            pendingKey = null
            hideOverlay()
            return
        }
        // لا نعتمد على rootInActiveWindow بعد الحظر؛ قد يصبح null أو يشير إلى
        // المشغّل/الستارة، وهذا لا ينبغي أن يرفع القفل.
        if (lockedPkg != null) { showOverlay(); return }

        val root = rootInActiveWindow ?: return
        val pkg = root.packageName?.toString() ?: return
        if (pkg == packageName || pkg in safe || !inWordScope(pkg)) return

        val hit = findWordFields(root, m, true).firstOrNull()
        if (hit == null) { pendingKey = null; return }

        val key = (hit.text ?: hit.contentDescription)?.toString()?.take(80).orEmpty()
        val now = SystemClock.elapsedRealtime()
        val strong = hit.isEditable ||
            (android.os.Build.VERSION.SDK_INT >= 28 && hit.isHeading) ||
            hit.viewIdResourceName?.contains("url", ignoreCase = true) == true
        if (strong || (key.isNotEmpty() && key == pendingKey && now - pendingSince >= 250)) {
            lockedPkg = pkg
            pendingKey = null
            showOverlay()
        } else {
            if (key != pendingKey) {
                pendingKey = key
                pendingSince = now
            }
            scheduleScan(300)
        }
    }

    private fun findWordFields(root: AccessibilityNodeInfo, m: Words.Matcher, firstOnly: Boolean): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        walkWords(root, m, 0, intArrayOf(0), firstOnly, out)
        return out
    }

    private fun walkWords(
        n: AccessibilityNodeInfo?, m: Words.Matcher, depth: Int, budget: IntArray,
        firstOnly: Boolean, out: MutableList<AccessibilityNodeInfo>
    ) {
        if (n == null || depth > 30 || budget[0] >= 1500) return
        if (firstOnly && out.isNotEmpty()) return
        budget[0]++
        if (!n.isVisibleToUser) return
        // أي نص ظاهر على الشاشة (نص عادي أو خانة إدخال أو وصف عنصر)، عدا حقول كلمات السر
        if (!n.isPassword && (m.matches(n.text) || m.matches(n.contentDescription))) {
            out.add(n)
            if (firstOnly) return
        }
        for (i in 0 until n.childCount) walkWords(n.getChild(i), m, depth + 1, budget, firstOnly, out)
    }

    private fun closeBlockedApp() {
        val pkg = lockedPkg
        // Device Owner can suspend a package; Android applies force-stop-like
        // behavior to it. We then unsuspend it so it can be opened again manually.
        val stopped = pkg?.let { Policy(this).stopPackageTemporarily(it) } == true
        performGlobalAction(GLOBAL_ACTION_HOME)
        handler.postDelayed({
            // Best-effort fallback only: this API alone does not guarantee force-stop.
            if (!stopped && pkg != null) {
                try {
                    getSystemService(android.app.ActivityManager::class.java)
                        .killBackgroundProcesses(pkg)
                } catch (_: Throwable) { }
            }
            lockedPkg = null
            pendingKey = null
            hideOverlay()
        }, 1900)
    }

    private fun showOverlay() {
        if (overlay != null) return
        try {
            val v = buildOverlay()
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.OPAQUE
            )
            getSystemService(WindowManager::class.java).addView(v, lp)
            overlay = v
        } catch (_: Throwable) {
            overlay = null
            performGlobalAction(GLOBAL_ACTION_HOME) // إن تعذّر عرض الواجهة نُخرج المستخدم على الأقل
        }
    }

    private fun hideOverlay() {
        val v = overlay ?: return
        overlay = null
        try { getSystemService(WindowManager::class.java).removeView(v) } catch (_: Throwable) { }
    }

    private fun buildOverlay(): View {
        val d = resources.displayMetrics.density
        fun dp(x: Int) = (x * d).toInt()
        fun label(t: String, size: Float, color: Int) = TextView(this).apply {
            text = t; textSize = size; setTextColor(color); gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(8))
        }
        fun button(t: String, onClick: () -> Unit) = Button(this).apply {
            text = t; setTextColor(Color.WHITE); setBackgroundColor(0xFF0F6B57.toInt())
            setOnClickListener { onClick() }
        }
        fun btnParams() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(14) }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(0xFF101418.toInt())
            setPadding(dp(28), dp(28), dp(28), dp(28))
            isClickable = true
            addView(label(getString(R.string.word_block_title), 26f, Color.WHITE))
            addView(label(getString(R.string.word_block_msg), 16f, 0xFFCCCCCC.toInt()))
            addView(button(getString(R.string.close_app)) { closeBlockedApp() }, btnParams())
        }
    }

    private fun launchBlock(site: Boolean, target: String) = launch(BlockActivity::class.java) {
        putExtra("site", site); putExtra("target", target)
    }

    private fun launchUnlock(mode: String, target: String?) = launch(UnlockActivity::class.java) {
        putExtra("mode", mode); putExtra("target", target)
    }

    private fun launch(cls: Class<*>, extras: Intent.() -> Unit) {
        val t = SystemClock.elapsedRealtime()
        if (t - lastLaunch < 800) return
        lastLaunch = t
        startActivity(
            Intent(this, cls)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NO_ANIMATION)
                .apply(extras)
        )
    }
}
