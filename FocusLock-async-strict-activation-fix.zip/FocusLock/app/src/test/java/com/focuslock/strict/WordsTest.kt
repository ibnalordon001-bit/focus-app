package com.focuslock.strict

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class WordsTest {
    @Test fun arabicDiacriticsAndTatweelAreIgnored() {
        val matcher = Words.Matcher(setOf("كتاب"))
        assertTrue(matcher.matches("كِتَاب"))
        assertTrue(matcher.matches("كــتاب"))
    }

    @Test fun taaMarbutaDoesNotCollapseIntoHaa() {
        val matcher = Words.Matcher(setOf("مدرسة"))
        assertTrue(matcher.matches("مدرسة"))
        assertFalse(matcher.matches("مدرسه"))
    }

    @Test fun boundariesPreventSubstringMatches() {
        val matcher = Words.Matcher(setOf("فن"))
        assertTrue(matcher.matches("هذا فن جميل"))
        assertFalse(matcher.matches("فنان"))
    }

    @Test fun commonArabicAffixesRemainSupportedWithoutSingleLetterSuffixes() {
        val matcher = Words.Matcher(setOf("كتاب"))
        assertTrue(matcher.matches("والكتاب"))
        assertTrue(matcher.matches("كتابهم"))
        assertFalse(matcher.matches("كتابك"))
    }

    @Test fun phraseAndSpacedLettersAreDetected() {
        assertTrue(Words.Matcher(setOf("محتوى محظور")).matches("هذا محتوى محظور هنا"))
        assertTrue(Words.Matcher(setOf("كلمةطويلة")).matches("ك ل م ة ط و ي ل ة"))
        assertFalse(Words.Matcher(setOf("كلمة")).matches("ك ل م ة"))
    }

    @Test fun englishCaseAndPluralAreSupported() {
        val matcher = Words.Matcher(setOf("BadWord"))
        assertTrue(matcher.matches("badword"))
        assertTrue(matcher.matches("badwords"))
        assertFalse(matcher.matches("notbadwordish"))
    }
}
