package com.focuslock.strict

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.database.ContentObserver
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

/** خدمة أمامية: تعيد تفعيل خدمة إمكانية الوصول إن أُطفئت، وتنهي الوضع الصارم عند انتهاء مدته. */
class GuardService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var observer: ContentObserver

    private val tick = object : Runnable {
        override fun run() {
            Strict.checkExpiry(this@GuardService)
            if (!Prefs(this@GuardService).isStrict()) {
                stopSelf()
                return
            }
            ensureA11y()
            Strict.syncDevOptions(this@GuardService)
            handler.postDelayed(this, 30_000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, getString(R.string.notif_channel), NotificationManager.IMPORTANCE_LOW)
        )
        observer = object : ContentObserver(handler) {
            override fun onChange(selfChange: Boolean) = ensureA11y()
        }
        contentResolver.registerContentObserver(
            Settings.Secure.getUriFor(Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES), false, observer
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(getString(R.string.notif_text))
            .setOngoing(true)
            .setContentIntent(open)
            .build()
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, 1, n, type)
        handler.removeCallbacks(tick)
        handler.post(tick)
        return START_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        contentResolver.unregisterContentObserver(observer)
        super.onDestroy()
    }

    private fun ensureA11y() {
        if (Prefs(this).isStrict() && !A11y.isEnabled(this)) A11y.tryEnable(this)
    }

    companion object {
        private const val CHANNEL = "strict"
        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, GuardService::class.java))
        }
    }
}
