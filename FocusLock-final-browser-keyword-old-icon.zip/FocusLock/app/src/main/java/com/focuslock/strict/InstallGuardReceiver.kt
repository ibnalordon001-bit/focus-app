package com.focuslock.strict

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log

/**
 * دفاع متعدد الطبقات عن تثبيت التطبيقات أثناء الوضع الصارم:
 * - يلتقط PACKAGE_ADDED مباشرة.
 * - يعلّق الحزمة الجديدة ثم يطلب إزالتها.
 * - يتحقق من نتيجة PackageInstaller ومن وجود الحزمة فعلياً.
 * - يعيد المحاولة عند الفشل، ويجري مسحاً دورياً للحزم الجديدة التي قد يفوت بثها.
 */
class InstallGuardReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val app = context.applicationContext
        val prefs = Prefs(app)
        val policy = Policy(app)

        when (intent.action) {
            Intent.ACTION_PACKAGE_ADDED -> {
                if (!prefs.isStrict() || !policy.isOwner()) return
                val packageName = intent.data?.schemeSpecificPart ?: return
                if (packageName == app.packageName) return

                val wasRegistered = packageName in prefs.registeredPackages
                val isReplacement = intent.getBooleanExtra(Intent.EXTRA_REPLACING, false)
                val installers = getInstallingPackages(app, packageName)
                val officialPlayUpdate = wasRegistered && isReplacement &&
                    GOOGLE_PLAY_PACKAGE in installers

                if (officialPlayUpdate) {
                    Log.i(TAG, "Allowed Google Play update for registered package: $packageName")
                    return
                }

                // لا نحذف التطبيق القديم إذا كان تحديثه من مصدر غير Play؛ نوقفه فقط.
                if (wasRegistered && isReplacement) {
                    try {
                        policy.suspendNewlyInstalledPackage(packageName)
                    } catch (t: Throwable) {
                        Log.w(TAG, "Could not suspend non-Play update: $packageName", t)
                    }
                    Log.w(TAG, "Non-Play update detected for registered package: $packageName; installers=$installers")
                    return
                }

                queueRemoval(app, packageName, "new package added")
            }

            ACTION_UNINSTALL_RESULT -> {
                val packageName = intent.getStringExtra(EXTRA_PACKAGE) ?: return
                val status = intent.getIntExtra(PackageInstallerStatus.EXTRA_STATUS, Int.MIN_VALUE)
                val message = intent.getStringExtra(PackageInstallerStatus.EXTRA_STATUS_MESSAGE)
                Log.i(TAG, "Uninstall callback for $packageName: status=$status message=$message")
                // لا نثق بنتيجة callback وحدها؛ نتحقق من PackageManager في retry/sweep.
                if (isInstalled(app, packageName) && prefs.isStrict()) {
                    scheduleRetry(app, packageName, prefs.nextRemovalRetryDelay(packageName))
                } else {
                    prefs.removePendingRemoval(packageName)
                    prefs.clearRemovalRetry(packageName)
                }
            }

            ACTION_RETRY -> {
                val packageName = intent.getStringExtra(EXTRA_PACKAGE) ?: return
                if (!prefs.isStrict() || !policy.isOwner()) {
                    prefs.removePendingRemoval(packageName)
                    prefs.clearRemovalRetry(packageName)
                    return
                }
                if (!isInstalled(app, packageName)) {
                    prefs.removePendingRemoval(packageName)
                    prefs.clearRemovalRetry(packageName)
                    return
                }
                requestRemoval(app, packageName)
            }

            ACTION_SWEEP -> {
                if (!prefs.isStrict() || !policy.isOwner()) return
                sweepNewPackages(app, prefs)
                scheduleSweep(app)
            }
        }
    }

    private fun queueRemoval(context: Context, packageName: String, reason: String) {
        val prefs = Prefs(context)
        prefs.addPendingRemoval(packageName)
        try {
            Policy(context).suspendNewlyInstalledPackage(packageName)
        } catch (t: Throwable) {
            // بعض حزم النظام/الحزم المحمية لا يمكن تعليقها؛ نواصل محاولة الحذف.
            Log.w(TAG, "Suspension unavailable for $packageName; continuing uninstall", t)
        }
        Log.w(TAG, "Queued removal for $packageName ($reason)")
        requestRemoval(context, packageName)
    }

    private fun requestRemoval(context: Context, packageName: String) {
        if (!isInstalled(context, packageName)) {
            Prefs(context).removePendingRemoval(packageName)
            Prefs(context).clearRemovalRetry(packageName)
            return
        }
        try {
            val callback = Intent(context, InstallGuardReceiver::class.java)
                .setAction(ACTION_UNINSTALL_RESULT)
                .putExtra(EXTRA_PACKAGE, packageName)
            val pending = PendingIntent.getBroadcast(
                context,
                packageName.hashCode(),
                callback,
                // PackageInstaller يضيف نتيجة العملية (STATUS / STATUS_MESSAGE) إلى IntentSender؛
                // لذلك يجب أن يكون PendingIntent قابلاً للتعديل على Android 12+.
                PendingIntent.FLAG_UPDATE_CURRENT or
                    (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) PendingIntent.FLAG_MUTABLE else 0)
            )
            context.packageManager.packageInstaller.uninstall(packageName, pending.intentSender)
            Log.i(TAG, "Uninstall request submitted for $packageName")
        } catch (t: Throwable) {
            Log.e(TAG, "Uninstall request failed for $packageName; scheduling retry", t)
        } finally {
            // حتى إن لم يصل callback، نعيد فحص الحالة ثم نحاول مجدداً عند الحاجة.
            val prefs = Prefs(context)
            scheduleRetry(context, packageName, prefs.nextRemovalRetryDelay(packageName))
        }
    }

    private fun sweepNewPackages(context: Context, prefs: Prefs) {
        val installed = try {
            InstallRegistry.currentPackages(context)
        } catch (t: Throwable) {
            Log.e(TAG, "Installed-package sweep failed", t)
            return
        }
        val unexpected = installed - prefs.registeredPackages - setOf(context.packageName)
        unexpected.forEach { packageName ->
            if (prefs.addPendingRemoval(packageName)) {
                queueRemoval(context, packageName, "periodic package sweep")
            } else if (isInstalled(context, packageName)) {
                // متابعة الحالات السابقة التي لم يكتمل حذفها.
                requestRemoval(context, packageName)
            }
        }
        // نظّف قائمة الانتظار من الحزم التي اختفت بالفعل.
        prefs.pendingRemovals.toList().forEach { packageName ->
            if (!isInstalled(context, packageName)) {
                prefs.removePendingRemoval(packageName)
                prefs.clearRemovalRetry(packageName)
            }
        }
        Log.i(TAG, "Package sweep complete; unexpected=${unexpected.size}")
    }

    private fun scheduleRetry(context: Context, packageName: String, delayMs: Long) {
        val intent = Intent(context, InstallGuardReceiver::class.java)
            .setAction(ACTION_RETRY)
            .putExtra(EXTRA_PACKAGE, packageName)
        val pending = PendingIntent.getBroadcast(
            context,
            packageName.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val alarm = context.getSystemService(AlarmManager::class.java)
        alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + delayMs, pending)
    }

    private fun scheduleSweep(context: Context) = schedulePeriodicSweep(context)

    @Suppress("DEPRECATION")
    private fun getInstallingPackages(context: Context, packageName: String): Set<String> = try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val source = context.packageManager.getInstallSourceInfo(packageName)
            setOfNotNull(source.installingPackageName, source.initiatingPackageName)
        } else {
            setOfNotNull(context.packageManager.getInstallerPackageName(packageName))
        }
    } catch (t: Throwable) {
        Log.w(TAG, "Could not determine installer for $packageName", t)
        emptySet()
    }

    @Suppress("DEPRECATION")
    private fun isInstalled(context: Context, packageName: String): Boolean = try {
        if (Build.VERSION.SDK_INT >= 33) {
            context.packageManager.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(0L))
        } else {
            context.packageManager.getPackageInfo(packageName, 0)
        }
        true
    } catch (_: PackageManager.NameNotFoundException) {
        false
    } catch (t: Throwable) {
        Log.w(TAG, "Could not verify installation state for $packageName", t)
        true // عند تعذر التحقق لا نعتبر الحذف ناجحاً.
    }

    companion object {
        fun startMonitoring(context: Context) = schedulePeriodicSweep(context.applicationContext)

        private fun schedulePeriodicSweep(context: Context) {
            val intent = Intent(context, InstallGuardReceiver::class.java).setAction(ACTION_SWEEP)
            val pending = PendingIntent.getBroadcast(
                context,
                SWEEP_REQUEST_CODE,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            context.getSystemService(AlarmManager::class.java).setAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                System.currentTimeMillis() + SWEEP_INTERVAL_MS,
                pending
            )
        }

        private const val TAG = "FocusLockInstallGuard"
        private const val GOOGLE_PLAY_PACKAGE = "com.android.vending"
        private const val EXTRA_PACKAGE = "package_name"
        private const val ACTION_UNINSTALL_RESULT = "com.focuslock.strict.INSTALL_GUARD_UNINSTALL_RESULT"
        private const val ACTION_RETRY = "com.focuslock.strict.INSTALL_GUARD_RETRY"
        private const val ACTION_SWEEP = "com.focuslock.strict.INSTALL_GUARD_SWEEP"
        private const val SWEEP_REQUEST_CODE = 78123
        private const val SWEEP_INTERVAL_MS = 15 * 60_000L
    }
}

/** ثوابت حالة PackageInstaller لتفادي الاعتماد على قيمة callback غير موثقة. */
private object PackageInstallerStatus {
    const val EXTRA_STATUS = "android.content.pm.extra.STATUS"
    const val EXTRA_STATUS_MESSAGE = "android.content.pm.extra.STATUS_MESSAGE"
}
