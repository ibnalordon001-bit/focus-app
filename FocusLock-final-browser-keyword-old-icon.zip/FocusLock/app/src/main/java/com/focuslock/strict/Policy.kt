package com.focuslock.strict

import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Build
import android.os.UserManager

class AdminReceiver : DeviceAdminReceiver() {
    override fun onDisableRequested(context: Context, intent: Intent): CharSequence =
        context.getString(R.string.admin_disable_warning)
}

/** كل ما يخص صلاحيات مالك الجهاز (Device Owner). */
class Policy(context: Context) {
    companion object {
        private const val GOOGLE_PLAY_PACKAGE = "com.android.vending"
        private const val DEVICE_WIDE_UNKNOWN_SOURCES_KEY = "verify_apps:device_wide_unknown_source_block"
    }
    private val ctx = context.applicationContext
    private val dpm = ctx.getSystemService(DevicePolicyManager::class.java)
    private val admin = ComponentName(ctx, AdminReceiver::class.java)

    fun isOwner(): Boolean = dpm.isDeviceOwnerApp(ctx.packageName)

    private fun restrictions(): List<String> = buildList {
        // منع تحكم المستخدم بالتطبيقات من الإعدادات. حماية إلغاء التثبيت أصبحت
        // لكل تطبيق مسجل عبر setUninstallBlocked حتى نستطيع إزالة التطبيقات الجديدة.
        add(UserManager.DISALLOW_APPS_CONTROL)
        // منع التثبيت الجانبي من المصادر غير الموثوقة مع إبقاء Google Play متاحاً.
        add(UserManager.DISALLOW_INSTALL_UNKNOWN_SOURCES)
        add(UserManager.ENSURE_VERIFY_APPS)
        add(UserManager.DISALLOW_SAFE_BOOT)           // منع Safe Mode
        add(UserManager.DISALLOW_FACTORY_RESET)       // منع مسح الجهاز من الإعدادات
        add(UserManager.DISALLOW_ADD_USER)            // منع إنشاء مستخدم جديد
        if (Build.VERSION.SDK_INT >= 28) add(UserManager.DISALLOW_CONFIG_DATE_TIME) // منع التلاعب بالساعة
    }

    /** خيارات المطور: مفتوحة خلال أول 72 ساعة من الوضع الصارم، ثم محظورة. */
    fun setDevOptionsBlocked(block: Boolean) {
        if (!isOwner()) return
        if (block) dpm.addUserRestriction(admin, UserManager.DISALLOW_DEBUGGING_FEATURES)
        else dpm.clearUserRestriction(admin, UserManager.DISALLOW_DEBUGGING_FEATURES)
    }

    /**
     * يلتقط القيمة الأصلية مرة واحدة حتى نعيدها عند إنهاء الوضع الصارم،
     * ولا نمسح إعدادات Managed Configurations الأخرى الخاصة بـ Google Play.
     */
    fun snapshotPlayInstallPolicy(prefs: Prefs) {
        if (!isOwner() || prefs.playUnknownSourcesSnapshotTaken) return
        try {
            val current = dpm.getApplicationRestrictions(admin, GOOGLE_PLAY_PACKAGE)
            prefs.playUnknownSourcesWasPresent = current.containsKey(DEVICE_WIDE_UNKNOWN_SOURCES_KEY)
            prefs.playUnknownSourcesPreviousValue = current.getBoolean(DEVICE_WIDE_UNKNOWN_SOURCES_KEY, false)
            prefs.playUnknownSourcesSnapshotTaken = true
        } catch (_: Throwable) {
            // تعذر قراءة إعداد Play؛ لا نوقف بدء الوضع الصارم بسبب ذلك.
        }
    }

    /** يفرض Google Play كمصدر التثبيت المسموح على مستوى الجهاز للمصادر غير الموثوقة. */
    private fun applyGooglePlayOnlyExternalSourcePolicy() {
        val current = dpm.getApplicationRestrictions(admin, GOOGLE_PLAY_PACKAGE)
        val updated = Bundle(current)
        updated.putBoolean(DEVICE_WIDE_UNKNOWN_SOURCES_KEY, true)
        dpm.setApplicationRestrictions(admin, GOOGLE_PLAY_PACKAGE, updated)
    }

    private fun restoreGooglePlayInstallPolicy(prefs: Prefs) {
        if (!prefs.playUnknownSourcesSnapshotTaken) return
        val current = dpm.getApplicationRestrictions(admin, GOOGLE_PLAY_PACKAGE)
        val updated = Bundle(current)
        if (prefs.playUnknownSourcesWasPresent) {
            updated.putBoolean(DEVICE_WIDE_UNKNOWN_SOURCES_KEY, prefs.playUnknownSourcesPreviousValue)
        } else {
            updated.remove(DEVICE_WIDE_UNKNOWN_SOURCES_KEY)
        }
        dpm.setApplicationRestrictions(admin, GOOGLE_PLAY_PACKAGE, updated)
        prefs.playUnknownSourcesSnapshotTaken = false
        prefs.playUnknownSourcesWasPresent = false
        prefs.playUnknownSourcesPreviousValue = false
    }

    fun applyStrict() {
        if (!isOwner()) return
        val prefs = Prefs(ctx)

        // نحمي كل التطبيقات التي كانت موجودة عند بدء الوضع الصارم بشكل فردي.
        // هذا يحافظ عليها، لكنه يترك التطبيقات الجديدة قابلة للإزالة بواسطة PackageInstaller.
        prefs.registeredPackages.forEach { packageName ->
            try {
                dpm.setUninstallBlocked(admin, packageName, true)
            } catch (_: Throwable) {
                // قد يكون تطبيق أزيل قبل إعادة تطبيق السياسة؛ نتجاوز الحزمة وحدها.
            }
        }
        dpm.setUninstallBlocked(admin, ctx.packageName, true)

        // ترحيل من النسخ السابقة: أزل القيد العام بعد تثبيت حماية الحزم القديمة.
        // DISALLOW_UNINSTALL_APPS كان يمنع إزالة أي حزمة، بما فيها التطبيقات الجديدة.
        dpm.clearUserRestriction(admin, UserManager.DISALLOW_UNINSTALL_APPS)

        restrictions().forEach { dpm.addUserRestriction(admin, it) }
        // هذا الإعداد يجعل منع المصادر غير الموثوقة على مستوى الجهاز، لا مجرد إعداد المستخدم.
        // يتطلب Google Play حديثاً (الإصدارات القديمة تتجاهل المفتاح غير المدعوم).
        if (prefs.playUnknownSourcesSnapshotTaken) {
            try {
                applyGooglePlayOnlyExternalSourcePolicy()
            } catch (_: Throwable) {
                // يبقى قيد DISALLOW_INSTALL_UNKNOWN_SOURCES فعالاً كحماية أساسية.
            }
        }
        setDevOptionsBlocked(!Strict.devGraceActive(prefs))
        if (Build.VERSION.SDK_INT >= 30) dpm.setAutoTimeEnabled(admin, true)
    }

    /** يوقف تشغيل تطبيق جديد مؤقتاً قبل إزالته أثناء الوضع الصارم. */
    fun suspendNewlyInstalledPackage(packageName: String) {
        if (!isOwner() || packageName == ctx.packageName) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            dpm.setPackagesSuspended(admin, arrayOf(packageName), true)
        }
    }

    fun releaseStrict() {
        if (!isOwner()) return
        val prefs = Prefs(ctx)
        restrictions().forEach { dpm.clearUserRestriction(admin, it) }
        dpm.clearUserRestriction(admin, UserManager.DISALLOW_UNINSTALL_APPS)
        dpm.clearUserRestriction(admin, UserManager.DISALLOW_DEBUGGING_FEATURES)
        // نرفع الحماية الفردية التي أضفناها للتطبيقات المسجلة فقط بعد انتهاء الوضع الصارم.
        prefs.registeredPackages.forEach { packageName ->
            try {
                dpm.setUninstallBlocked(admin, packageName, false)
            } catch (_: Throwable) {
                // تجاهل الحزم التي لم تعد مثبتة.
            }
        }
        try {
            restoreGooglePlayInstallPolicy(prefs)
        } catch (_: Throwable) {
            // لا نمنع إنهاء الوضع الصارم إذا تعذر استرجاع إعداد Google Play.
        }
        dpm.setUninstallBlocked(admin, ctx.packageName, false)
    }

    @Suppress("DEPRECATION")
    fun relinquishOwner() {
        if (isOwner()) {
            releaseStrict()
            dpm.clearDeviceOwnerApp(ctx.packageName)
        }
    }
}
