package com.focuslock.strict

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Bitmap
import android.os.Build
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Display
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * يرصد التطبيق/الموقع/الشاشة في المقدمة:
 *  - أثناء الوضع الصارم: يحظر التطبيقات والمواقع المختارة، ويحمي شاشات الإعدادات الحساسة بكلمة السر.
 *  - دائماً: يطلب كلمة السر قبل فتح التطبيقات المحمية.
 */
class GuardAccessibilityService : AccessibilityService() {
    private val prefs by lazy { Prefs(this) }
    private var safe: Set<String> = emptySet()
    private var browsers: Set<String> = emptySet()
    // المتصفحات تُراقب تلقائياً، حتى لو ثُبّتت بعد تفعيل الوضع الصارم.
    private var wordBrowsers: Set<String> = emptySet()
    private var refreshedAt = 0L
    private var lastForegroundPkg: String? = null
    private var lastLaunch = 0L
    private var lastSiteCheck = 0L
    private var lastSettingsCheck = 0L

    // ---- حظر الكلمات المفتاحية ----
    private val handler = Handler(Looper.getMainLooper())
    private var overlay: View? = null
    private var lockedPkg: String? = null
    private var lockedByVisual = false
    private var pendingKey: String? = null
    private var pendingSince = 0L
    private var scanPending = false
    private var scanDueAt = 0L
    // نخزّن المطابق ولا نعيد بناءه إلا عند تغيّر قائمة الكلمات؛ قراءة آلاف الأسطر
    // ومقارنتها عند كل حدث accessibility كانت ستُبطئ الخدمة.
    private var wordsDirty = true
    private val prefsListener = android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == null || key == "blockedWords") wordsDirty = true
    }
    private var matcher = Words.Matcher(emptySet())
    // جلسة البحث لا تبدأ إلا عند التفاعل مع حقل بحث حقيقي، وتنتهي عند مغادرة سياقه.
    private var searchPkg: String? = null
    private var searchQuery: String = ""
    private var searchSubmitted = false
    private var searchResultTransitionSeen = false
    private var searchLastSignal = 0L
    private var submittedQuery = ""
    private var searchSubmitAt = 0L

    // ---- الفحص البصري المحلي ----
    private val visualClassifierDelegate = lazy { VisualNsfwClassifier(this) }
    private val visualClassifier by visualClassifierDelegate
    private val visualCaptureExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private var visualCaptureInFlight = false
    private var lastVisualCaptureAt = 0L
    private var visualEvidencePackage: String? = null
    private var visualHitStreak = 0
    private val scanRunnable = Runnable {
        scanPending = false
        scanDueAt = 0L
        try { checkWords() } catch (_: Throwable) { /* لا نترك الخدمة تنهار */ }
    }

    // لا نعتمد على وصول حدث جديد فقط: افحص النافذة الحالية دورياً، خصوصاً
    // عند تفعيل الوضع الصارم والخدمة متصلة بالفعل أو عند ضياع حدث من النظام.
    private val foregroundPoll = object : Runnable {
        override fun run() {
            try {
                val root = rootInActiveWindow
                val pkg = root?.packageName?.toString()
                if (!pkg.isNullOrBlank()) {
                    val event = AccessibilityEvent.obtain(AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED)
                    event.packageName = pkg
                    // نعيد مراقبة النافذة الحالية دورياً حتى لا تفوتنا الاقتراحات والنتائج
                    // التي تُضاف إلى الشجرة دون حدث Accessibility مستقل.
                    try { handle(event) } finally { event.recycle() }
                }
            } catch (_: Throwable) { /* لا نترك الفحص الدوري يُسقط الخدمة */ }
            handler.postDelayed(this, FOREGROUND_POLL_MS)
        }
    }

    companion object {
        private const val FOREGROUND_POLL_MS = 1_000L
        /** بعد إرسال البحث لا تنتهي الجلسة بسبب انتقالات الشاشة خلال هذه المدة (تحميل النتائج). */
        private const val RESULTS_GRACE_MS = 60_000L
        /** مدة إعادة الفحص تلقائياً بعد الإرسال إذا لم تظهر النتائج بعد. */
        private const val RESULTS_RETRY_MS = 10_000L
        /** Keep whole-screen protection active on result pages even when the app drops search view IDs. */
        private const val MAX_SEARCH_NODES = 5000
        private const val MAX_SEARCH_TEXT = 64000
        private const val VISUAL_CAPTURE_INTERVAL_MS = 1_400L
    }

    private val sensitiveAll by lazy {
        Guard.SENSITIVE_KEYWORDS +
            listOf("سهولة الوصول", "خيارات المطوّر", "للمطورين", "device manager").map { it.lowercase() } +
            listOf(getString(R.string.app_name), getString(R.string.service_label)).map { it.lowercase() }
    }
    private val devWords by lazy { Guard.DEV_KEYWORDS.map { it.lowercase() }.toSet() }
    private val sensitiveNoDev by lazy { sensitiveAll.filter { it !in devWords } }

    /** خلال أول 72 ساعة من الوضع الصارم لا نحمي شاشة خيارات المطور. */
    private fun sensitive(): List<String> = if (Strict.devGraceActive(prefs)) sensitiveNoDev else sensitiveAll

    override fun onServiceConnected() {
        super.onServiceConnected()
        wordsDirty = true
        getSharedPreferences("focuslock", MODE_PRIVATE).registerOnSharedPreferenceChangeListener(prefsListener)
        // عند إعادة اتصال الخدمة بعد قتل العملية (مثلاً سحب التطبيق) نعيد تشغيل خدمة الحماية فوراً.
        if (prefs.isStrict()) {
            GuardService.start(this)
            Strict.scheduleWatchdog(this, Strict.WATCHDOG_MS)
        }
        refresh()
        handler.removeCallbacks(foregroundPoll)
        // افحص التطبيق الظاهر فور اتصال الخدمة، ثم استمر بالفحص كل ثانية.
        foregroundPoll.run()
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        try { getSharedPreferences("focuslock", MODE_PRIVATE).unregisterOnSharedPreferenceChangeListener(prefsListener) } catch (_: Throwable) { }
        handler.removeCallbacks(scanRunnable)
        handler.removeCallbacks(foregroundPoll)
        if (visualClassifierDelegate.isInitialized()) visualClassifier.close()
        visualCaptureExecutor.shutdownNow()
        hideOverlay()
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        try { handle(event) } catch (_: Throwable) { /* لا نترك الخدمة تنهار أبداً */ }
    }

    private fun refresh() {
        safe = Guard.protectedPackages(this)
        browsers = Guard.browserPackages(this)
        wordBrowsers = Guard.realBrowserPackages(this)
        refreshedAt = SystemClock.elapsedRealtime()
    }

    private fun handle(e: AccessibilityEvent?) {
        val pkg = e?.packageName?.toString() ?: return
        // القفل المؤكد لا يسقط بتبديل النافذة أو فتح الإشعارات أو الشاشة الرئيسية.
        if (lockedPkg != null) {
            if (!prefs.isStrict() || (!lockedByVisual && currentMatcher().isEmpty)) {
                lockedPkg = null
                lockedByVisual = false
                pendingKey = null
                hideOverlay()
            } else {
                if (overlay == null) showOverlay()
                return
            }
        }
        if (pkg == packageName) {
            // فتح FocusLock نفسه يعني مغادرة سياق البحث؛ لا نُبقِي جلسة قديمة
            // نشطة إذا عاد المستخدم لاحقاً إلى التطبيق المستهدف.
            if (searchPkg != null) resetSearchSession()
            return
        }
        val now = SystemClock.elapsedRealtime()
        val stateChange = e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
        // عند فتح تطبيق جديد نعيد اكتشاف المتصفحات، حتى نلتقط المتصفح المثبّت حديثاً.
        val newForeground = stateChange && pkg != lastForegroundPkg
        if (newForeground) lastForegroundPkg = pkg
        if (now - refreshedAt > 120_000 || (newForeground && pkg !in wordBrowsers)) refresh()
        if (prefs.strictEndAt > 0 && !prefs.isStrict()) Strict.end(this)
        if (pkg in safe) return

        val strict = prefs.isStrict()

        if (strict && inWordScope(pkg)) {
            // تشمل المراقبة أحداث النظام والفحص الدوري، لالتقاط تحديثات البحث المتأخرة.
            watchWords(e)
            if (lockedPkg != null) return
        } else if (searchPkg != null && pkg != searchPkg && stateChange) {
            // لا ننهي جلسة البحث بسبب أحداث لوحة المفاتيح (Gboard مثلاً).
            // ننهيها فقط عندما تصبح نافذة تطبيق آخر هي النافذة النشطة فعلياً.
            val activePkg = rootInActiveWindow?.packageName?.toString()
            if (!activePkg.isNullOrBlank() && activePkg != searchPkg && activePkg == pkg) {
                resetSearchSession()
            }
        }

        if (strict && (pkg in wordBrowsers || (pkg in prefs.keywordApps && searchPkg == pkg))) {
            requestVisualCapture(pkg)
        }

        if (strict && pkg in prefs.blockedApps) { launchBlock(site = false, target = pkg); return }

        if (stateChange && pkg in prefs.lockedApps &&
            (Guard.appGrace[pkg] ?: 0L) < System.currentTimeMillis()
        ) { launchUnlock("app", pkg); return }

        if (!strict) return

        if (pkg in browsers) {
            if (now - lastSiteCheck > 400) { lastSiteCheck = now; checkBrowser(pkg) }
            return
        }
        if (pkg in Guard.SETTINGS) {
            if (System.currentTimeMillis() > prefs.graceUntil && now - lastSettingsCheck > 300) {
                lastSettingsCheck = now
                if ((stateChange && isSensitive(e)) || titleSensitive()) launchUnlock("settings", null)
            }
        }
    }

    /** يقرأ نصوص أعلى الشاشة (العنوان) ويتجاهل صفوف القوائم القابلة للضغط. */
    private fun titleSensitive(): Boolean {
        val root = rootInActiveWindow ?: return false
        if (root.packageName?.toString() !in Guard.SETTINGS) return false
        return scanTitles(root, 0, resources.displayMetrics.heightPixels * 0.30)
    }

    private fun scanTitles(n: AccessibilityNodeInfo?, depth: Int, limit: Double): Boolean {
        if (n == null || depth > 15) return false
        val txt = n.text?.toString()?.lowercase()
        if (!txt.isNullOrEmpty() && !n.isClickable && n.parent?.isClickable != true &&
            n.parent?.parent?.isClickable != true && sensitive().any { txt.contains(it) }
        ) {
            val r = Rect()
            n.getBoundsInScreen(r)
            if (r.top < limit && r.bottom > 0) return true
        }
        for (i in 0 until n.childCount) if (scanTitles(n.getChild(i), depth + 1, limit)) return true
        return false
    }

    private fun isSensitive(e: AccessibilityEvent): Boolean {
        val text = ((e.text?.joinToString(" ") ?: "") + " " + (e.className ?: "")).lowercase()
        return sensitive().any { text.contains(it) }
    }

    private fun checkBrowser(pkg: String) {
        val sites = prefs.blockedSites
        if (sites.isEmpty()) return
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != pkg) return
        val url = findUrl(root, pkg) ?: return
        val host = Guard.normalizeDomain(url) ?: return
        if (Guard.isBlocked(host, sites)) launchBlock(site = true, target = host)
    }

    private fun findUrl(root: AccessibilityNodeInfo, pkg: String): String? {
        Guard.URL_BAR_IDS[pkg]?.forEach { id ->
            val t = root.findAccessibilityNodeInfosByViewId(id).firstOrNull()?.text
            if (!t.isNullOrBlank()) return t.toString()
        }
        return scan(root, 0) // متصفح غير معروف: نبحث عن حقل نص يشبه شريط العنوان
    }

    private fun scan(n: AccessibilityNodeInfo?, depth: Int): String? {
        if (n == null || depth > 12) return null
        val id = n.viewIdResourceName.orEmpty().lowercase()
        val looksLikeBar = n.className?.contains("EditText") == true ||
            id.contains("url") || id.contains("omnibox") || id.contains("address")
        if (looksLikeBar && !n.text.isNullOrBlank()) return n.text.toString()
        for (i in 0 until n.childCount) scan(n.getChild(i), depth + 1)?.let { return it }
        return null
    }

    // ======================= حظر الكلمات المفتاحية =======================

    private fun currentMatcher(): Words.Matcher {
        if (wordsDirty) {
            wordsDirty = false
            matcher = Words.Matcher(prefs.blockedWords)
        }
        return matcher
    }

    /** كل المتصفحات تُراقب تلقائياً؛ اختيار المستخدم مطلوب للتطبيقات العادية فقط. */
    private fun inWordScope(pkg: String): Boolean = pkg in wordBrowsers || pkg in prefs.keywordApps

    private fun markSubmitted(now: Long, refresh: Boolean) {
        if (!searchSubmitted || refresh) searchSubmitAt = now
        searchSubmitted = true
        submittedQuery = searchQuery
    }

    /** لا تبدأ الرقابة إلا داخل سياق البحث، وتشمل الكتابة والاقتراحات والنتائج. */
    private fun watchWords(e: AccessibilityEvent) {
        val m = currentMatcher()
        val pkg = e.packageName?.toString() ?: return
        // Visual protection has its own search-session tracking and remains active
        // even when the user has not configured any blocked keywords.
        if (m.isEmpty) {
            updateVisualSearchSession(e, pkg)
            if (searchPkg == pkg) requestVisualCapture(pkg)
            return
        }

        // المسار الأسرع: افحص العنصر الذي أرسل حدث الكتابة قبل طلب شجرة الواجهة.
        // لا نعدّ أي EditText حقل بحث؛ يجب أن يحمل هو أو أحد آبائه دلالة بحث.
        val source = e.source
        val sourceId = source?.viewIdResourceName.orEmpty().lowercase()
        val sourceLabel = ((source?.hintText?.toString().orEmpty()) + " " +
            (source?.text?.toString().orEmpty()) + " " +
            (source?.contentDescription?.toString().orEmpty())).lowercase()
        val sourceText = source?.text?.toString().orEmpty()
        val sourceEditable = source?.isEditable == true
        val directSearchSource = source != null && isSearchFieldSource(source)
        // زر البحث قد لا يحمل اسماً معروفاً (أيقونة بلا وصف)؛ أي نقر على عنصر غير قابل للكتابة
        // داخل جلسة بحث فيها عبارة يُعدّ إرسالاً.
        val submitAction = e.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED &&
            (sourceId.contains("search") || sourceId.contains("submit") || sourceId.contains("suggest") ||
                sourceLabel.contains("search") || sourceLabel.contains("بحث") || sourceLabel.contains("enter") ||
                sourceLabel.contains("go") ||
                (searchPkg == pkg && searchQuery.isNotBlank() && !sourceEditable))
        try {
            if (directSearchSource &&
                (e.eventType == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED ||
                    e.eventType == AccessibilityEvent.TYPE_VIEW_FOCUSED) &&
                source != null && source.isEditable && !source.isPassword && m.matches(sourceText)) {
                searchPkg = pkg
                searchLastSignal = SystemClock.elapsedRealtime()
                searchQuery = sourceText
                searchSubmitted = false
                searchResultTransitionSeen = false
                lockKeyword(pkg)
                return
            }
        } finally {
            source?.recycle()
        }

        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != pkg) return
        val field = findSearchField(root)
        val now = SystemClock.elapsedRealtime()

        if (field != null) {
            searchPkg = pkg
            searchLastSignal = now
            val value = field.text?.toString().orEmpty()
            if (value.isNotBlank()) searchQuery = value
            // لا نلغي حالة الإرسال لمجرد أن التطبيق أعاد ضبط نص الحقل أو تركيزه برمجياً
            // (يحدث كثيراً عند ظهور النتائج). نبدأ بحثاً جديداً فقط عندما يتغير نص الحقل فعلاً
            // عمّا أُرسل، أي أن المستخدم يكتب عبارة جديدة.
            if (e.eventType == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED &&
                (!searchSubmitted || value.trim() != submittedQuery.trim())) {
                searchSubmitted = false
                searchResultTransitionSeen = false
            }
            // بعض التطبيقات تبقي مربع البحث أعلى صفحة النتائج؛ فقدانه للتركيز
            // مع تغيّر محتوى النافذة بعد وجود عبارة بحث يعني أن النتائج بدأت بالظهور.
            if (searchQuery.isNotBlank() && !field.isFocused &&
                e.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {
                markSubmitted(now, refresh = false)
            }
        }
        if (submitAction && searchPkg == pkg) {
            markSubmitted(now, refresh = true)
            searchResultTransitionSeen = false
            searchLastSignal = now
        }

        val hasSearchMarkers = hasSearchUiMarkers(root)
        if (searchPkg == pkg && hasSearchMarkers) searchLastSignal = now

        // عند انتقال المستخدم إلى شاشة أخرى داخل التطبيق، لا نُبقي الرقابة فعالة
        // إلا إذا بقيت عناصر واجهة البحث/الاقتراحات/النتائج ظاهرة.
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && field == null &&
            !hasSearchMarkers && !submitAction) {
            // الإرسال بزر Enter في لوحة المفاتيح لا يولّد حدث نقر، فلا يُضبط searchSubmitted.
            // لذلك: وجود عبارة بحث ثم اختفاء الحقل في أول انتقال = ظهور صفحة النتائج.
            // صفحات النتائج كثيراً ما تُطلق أكثر من انتقال نافذة أثناء التحميل، فنمهل الجلسة قليلاً.
            val withinGrace = searchSubmitted && now - searchSubmitAt < RESULTS_GRACE_MS
            if (withinGrace || ((searchSubmitted || searchQuery.isNotBlank()) && !searchResultTransitionSeen)) {
                // أول انتقال بعد إرسال البحث هو غالباً ظهور صفحة النتائج نفسها.
                markSubmitted(now, refresh = false)
                searchResultTransitionSeen = true
            } else {
                // انتقال لاحق إلى شاشة أخرى داخل التطبيق يعني مغادرة سياق النتائج.
                resetSearchSession()
                return
            }
        }
        if (searchPkg != pkg) return
        if (!searchSubmitted && now - searchLastSignal > 12_000 && field == null && !hasSearchMarkers) {
            resetSearchSession()
            return
        }
        if (field == null && !hasSearchMarkers && !searchSubmitted) return
        scheduleScan(if (e.eventType == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) 0 else 100)
        try { field?.recycle() } catch (_: Throwable) { }
    }

    /** Search-only visual scope for selected ordinary apps, independent of keyword lists. */
    private fun updateVisualSearchSession(e: AccessibilityEvent, pkg: String) {
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != pkg) return
        val field = findSearchField(root)
        val markers = hasSearchUiMarkers(root)
        val source = e.source
        val sourceId = source?.viewIdResourceName.orEmpty().lowercase()
        val sourceLabel = ((source?.hintText?.toString().orEmpty()) + " " +
            (source?.text?.toString().orEmpty()) + " " +
            (source?.contentDescription?.toString().orEmpty())).lowercase()
        val sourceEditable = source?.isEditable == true
        // Search buttons are inconsistently labelled across apps. Once a real search
        // field and query have been observed, a click on a non-editable control is
        // treated as submit (same fallback used by keyword scanning).
        val submitAction = e.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED &&
            (sourceId.contains("search") || sourceId.contains("submit") || sourceId.contains("suggest") ||
                sourceLabel.contains("search") || sourceLabel.contains("بحث") || sourceLabel.contains("enter") ||
                sourceLabel.contains("go") ||
                (searchPkg == pkg && searchQuery.isNotBlank() && !sourceEditable))
        val now = SystemClock.elapsedRealtime()
        try {
            if (field != null) {
                searchPkg = pkg
                searchLastSignal = now
                val value = field.text?.toString().orEmpty()
                if (value.isNotBlank()) searchQuery = value
                // Do not mistake the app clearing/refocusing its search box after
                // submission for a new query. Only an actual changed query restarts it.
                if (e.eventType == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED &&
                    searchSubmitted && value.trim() != submittedQuery.trim()) {
                    searchSubmitted = false
                    searchResultTransitionSeen = false
                } else if (e.eventType == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED && !searchSubmitted) {
                    searchResultTransitionSeen = false
                }
                if (searchQuery.isNotBlank() && !field.isFocused &&
                    e.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {
                    markSubmitted(now, refresh = false)
                }
            }
            if (submitAction && searchPkg == pkg && searchQuery.isNotBlank()) {
                markSubmitted(now, refresh = true)
                searchResultTransitionSeen = false
            }
        } finally {
            try { source?.recycle() } catch (_: Throwable) { }
        }

        if (searchPkg == pkg && markers) searchLastSignal = now

        // Some apps remove the search widget entirely when opening results. Treat
        // the first window transition after a captured query as submission even
        // when Enter generated no click event and result nodes have no search IDs.
        if (searchPkg == pkg && searchQuery.isNotBlank() && field == null && !markers &&
            (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED ||
                e.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) && !searchSubmitted) {
            markSubmitted(now, refresh = true)
            searchResultTransitionSeen = true
        }

        // لا ننهي جلسة النتائج بمهلة ثابتة؛ قد تبقى صفحة البحث مفتوحة أكثر من دقيقة
        // وتُحمّل نتائج جديدة لاحقاً. تنتهي الجلسة عند مغادرة التطبيق أو بدء بحث جديد.
        if (!searchSubmitted && now - searchLastSignal > 12_000L && field == null && !markers) {
            resetSearchSession()
        }
        try { field?.recycle() } catch (_: Throwable) { }
    }

    private fun isVisualScopeActive(pkg: String): Boolean =
        pkg in wordBrowsers || (pkg in prefs.keywordApps && searchPkg == pkg)

    /** Captures the visible display at a conservative cadence; inference runs off the UI thread. */
    private fun requestVisualCapture(pkg: String) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R || !prefs.isStrict() ||
            lockedPkg != null || !isVisualScopeActive(pkg)
        ) return
        val now = SystemClock.elapsedRealtime()
        if (visualCaptureInFlight || now - lastVisualCaptureAt < VISUAL_CAPTURE_INTERVAL_MS) return
        visualCaptureInFlight = true
        lastVisualCaptureAt = now
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, visualCaptureExecutor,
                object : AccessibilityService.TakeScreenshotCallback {
                    override fun onSuccess(screenshot: AccessibilityService.ScreenshotResult) {
                        var bitmap: Bitmap? = null
                        val hardware = screenshot.hardwareBuffer
                        try {
                            val wrapped = Bitmap.wrapHardwareBuffer(hardware, screenshot.colorSpace)
                            bitmap = wrapped?.copy(Bitmap.Config.ARGB_8888, false)
                        } catch (_: Throwable) {
                        } finally {
                            try { hardware.close() } catch (_: Throwable) { }
                        }
                        val captured = bitmap
                        if (captured == null) {
                            handler.post { visualCaptureInFlight = false }
                            return
                        }
                        visualClassifier.analyze(captured) { scores ->
                            handler.post {
                                visualCaptureInFlight = false
                                if (scores != null && pkg == rootInActiveWindow?.packageName?.toString() &&
                                    prefs.isStrict() && isVisualScopeActive(pkg) && lockedPkg == null
                                ) evaluateVisualScores(pkg, scores)
                            }
                        }
                    }

                    override fun onFailure(errorCode: Int) {
                        handler.post { visualCaptureInFlight = false }
                    }
                })
        } catch (_: Throwable) {
            visualCaptureInFlight = false
        }
    }

    /** Nudity is blocked immediately; "sexy" needs repeat confirmation. Both use calibrated thresholds. */
    private fun evaluateVisualScores(pkg: String, scores: VisualNsfwClassifier.Scores) {
        if (visualEvidencePackage != pkg) {
            visualEvidencePackage = pkg
            visualHitStreak = 0
        }
        // Thresholds are calibrated in Colab (validation precision >= 95%) and shipped in assets.
        val explicitHit = scores.nudityBlocks || scores.bodyExplicit
        val suggestiveHit = scores.sexyBlocks || scores.bodyRevealing
        if (explicitHit) {
            visualHitStreak = 2
        } else if (suggestiveHit) {
            visualHitStreak++
        } else {
            visualHitStreak = 0
        }
        if (visualHitStreak >= 2) {
            lockedPkg = pkg
            lockedByVisual = true
            pendingKey = null
            visualHitStreak = 0
            showOverlay()
        }
    }

    private fun resetSearchSession() {
        searchPkg = null
        searchQuery = ""
        searchSubmitted = false
        searchResultTransitionSeen = false
        searchLastSignal = 0L
        submittedQuery = ""
        searchSubmitAt = 0L
        visualEvidencePackage = null
        visualHitStreak = 0
        pendingKey = null
        handler.removeCallbacks(scanRunnable)
        scanPending = false
        scanDueAt = 0L
    }

    private fun nodeId(n: AccessibilityNodeInfo?): String = n?.viewIdResourceName.orEmpty().lowercase()
    private fun nodeLabel(n: AccessibilityNodeInfo?): String =
        ((n?.hintText?.toString().orEmpty()) + " " +
            (n?.contentDescription?.toString().orEmpty())).lowercase()

    private fun isSearchNode(n: AccessibilityNodeInfo): Boolean {
        val id = nodeId(n)
        val label = nodeLabel(n)
        return id.contains("search") || id.contains("query") || id.contains("autocomplete") ||
            id.contains("omnibox") || id.contains("find") ||
            label.contains("search") || label.contains("find") || label.contains("query") ||
            label.contains("بحث") || label.contains("ابحث") || label.contains("اكتب للبحث")
    }

    /** يتحقق من أن مصدر الحدث حقل بحث أو تابع لحاوية بحث معروفة. */
    private fun isSearchFieldSource(source: AccessibilityNodeInfo): Boolean {
        if (!source.isVisibleToUser || !source.isEditable || source.isPassword) return false
        var node: AccessibilityNodeInfo? = source
        var owned = false
        var depth = 0
        while (node != null && depth++ < 6) {
            val current = node
            val matches = isSearchNode(current)
            val parent = if (!matches) current.parent else null
            if (owned) try { current.recycle() } catch (_: Throwable) { }
            if (matches) return true
            node = parent
            owned = parent != null
        }
        return false
    }

    private fun lockKeyword(pkg: String) {
        lockedPkg = pkg
        lockedByVisual = false
        pendingKey = null
        handler.removeCallbacks(scanRunnable)
        scanPending = false
        scanDueAt = 0L
        showOverlay()
    }

    private fun findSearchField(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val queue = ArrayDeque<Pair<AccessibilityNodeInfo, Boolean>>()
        queue.add(root to false)
        var visited = 0
        var found: AccessibilityNodeInfo? = null
        while (queue.isNotEmpty() && visited++ < 3000) {
            val (node, owned) = queue.removeFirst()
            val matches = node.isVisibleToUser && !node.isPassword && node.isEditable && isSearchNode(node)
            if (matches) {
                found = AccessibilityNodeInfo.obtain(node)
                if (owned) try { node.recycle() } catch (_: Throwable) { }
                break
            }
            for (i in 0 until node.childCount) node.getChild(i)?.let { queue.addLast(it to true) }
            if (owned) try { node.recycle() } catch (_: Throwable) { }
        }
        while (queue.isNotEmpty()) {
            val (remaining, owned) = queue.removeFirst()
            if (owned) try { remaining.recycle() } catch (_: Throwable) { }
        }
        return found
    }

    private fun hasSearchUiMarkers(root: AccessibilityNodeInfo): Boolean {
        val queue = ArrayDeque<Pair<AccessibilityNodeInfo, Boolean>>()
        queue.add(root to false)
        var visited = 0
        var found = false
        while (queue.isNotEmpty() && visited++ < 3000) {
            val (node, owned) = queue.removeFirst()
            if (node.isVisibleToUser) {
                val id = nodeId(node)
                val label = nodeLabel(node)
                if (id.contains("search") || id.contains("suggest") || id.contains("autocomplete") ||
                    id.contains("search_result") || id.contains("searchresult") ||
                    label.contains("suggest") || label.contains("autocomplete") ||
                    label.contains("اقتراح") || label.contains("نتائج البحث")) found = true
            }
            if (!found) for (i in 0 until node.childCount) node.getChild(i)?.let { queue.addLast(it to true) }
            if (owned) try { node.recycle() } catch (_: Throwable) { }
            if (found) break
        }
        while (queue.isNotEmpty()) {
            val (remaining, owned) = queue.removeFirst()
            if (owned) try { remaining.recycle() } catch (_: Throwable) { }
        }
        return found
    }

    private fun scheduleScan(delayMs: Long) {
        val dueAt = SystemClock.uptimeMillis() + delayMs.coerceAtLeast(0L)
        // Keep the earliest requested scan. A text-edit event (0 ms) must not
        // wait behind an older, slower content-change scan (500 ms).
        if (scanPending && dueAt >= scanDueAt) return
        if (scanPending) handler.removeCallbacks(scanRunnable)
        scanPending = true
        scanDueAt = dueAt
        handler.postAtTime(scanRunnable, dueAt)
    }

    /** قفل ثابت بعد تأكيد الكلمة، مع تأكيد ثانٍ للنصوص غير القابلة للتحرير. */
    private fun checkWords() {
        val m = currentMatcher()
        if (!prefs.isStrict() || (m.isEmpty && !lockedByVisual)) {
            lockedPkg = null
            lockedByVisual = false
            pendingKey = null
            hideOverlay()
            return
        }
        // لا نعتمد على rootInActiveWindow بعد الحظر؛ قد يصبح null أو يشير إلى
        // المشغّل/الستارة، وهذا لا ينبغي أن يرفع القفل.
        if (lockedPkg != null) { showOverlay(); return }

        val root = rootInActiveWindow ?: return
        val pkg = root.packageName?.toString() ?: return
        if (pkg == packageName || pkg in safe || !inWordScope(pkg)) return

        if (searchPkg != pkg) return
        val scan = collectSearchContextText(root, m, searchSubmitted)
        if (scan == null) {
            pendingKey = null
            // قد تُحمَّل النتائج بعد الإرسال دون أحداث جديدة؛ نعيد الفحص لفترة قصيرة.
            if (searchSubmitted && SystemClock.elapsedRealtime() - searchSubmitAt < RESULTS_RETRY_MS) scheduleScan(400)
            return
        }
        // المفتاح هو الكلمة المطابقة نفسها (وليس أول 120 حرفاً من الشاشة) حتى يبقى ثابتاً
        // بين الفحصين ولا يفشل تأكيد الحظر في النتائج بسبب تغيّر نص آخر على الشاشة.
        val (editableHit, key) = scan
        val now = SystemClock.elapsedRealtime()
        // بعد إرسال البحث نحظر فور ظهور الكلمة في النتائج دون انتظار فحص ثانٍ.
        val strong = editableHit || searchSubmitted
        // نص خانة البحث يُحظر فوراً؛ الاقتراح/النتيجة يلزم ظهورها في فحصين متتاليين.
        if (strong || (key.isNotEmpty() && key == pendingKey && now - pendingSince >= 90)) {
            lockedPkg = pkg
            pendingKey = null
            showOverlay()
        } else {
            if (key != pendingKey) {
                pendingKey = key
                pendingSince = now
            }
            scheduleScan(90)
        }
    }

    /** يجمع نص البحث والاقتراحات؛ وبعد الإرسال يفحص كامل شجرة الشاشة الظاهرة. */
    private fun collectSearchContextText(
        root: AccessibilityNodeInfo, m: Words.Matcher, includeResults: Boolean
    ): Pair<Boolean, String>? {
        val text = StringBuilder()
        var strongHit = false
        val budget = intArrayOf(0)
        // لا نبحث عن الحقل بعد الإرسال؛ نمسح الشاشة مباشرة من الجذر لتقليل التأخير.
        val field = if (includeResults) null else findSearchField(root)

        fun appendNode(node: AccessibilityNodeInfo?, depth: Int, maxDepth: Int) {
            if (node == null || depth > maxDepth || budget[0] >= MAX_SEARCH_NODES ||
                text.length >= MAX_SEARCH_TEXT
            ) return
            budget[0]++
            if (!node.isVisibleToUser || node.isPassword) return

            val value = node.text?.toString().orEmpty()
            val desc = node.contentDescription?.toString().orEmpty()
            if (value.isNotBlank()) {
                if (!strongHit && node.isEditable && m.matches(value)) strongHit = true
                text.append(value).append(' ')
            }
            if (desc.isNotBlank()) text.append(desc).append(' ')
            for (i in 0 until node.childCount) {
                if (budget[0] >= MAX_SEARCH_NODES || text.length >= MAX_SEARCH_TEXT) break
                val child = node.getChild(i) ?: continue
                try { appendNode(child, depth + 1, maxDepth) }
                finally { try { child.recycle() } catch (_: Throwable) { } }
            }
        }

        if (includeResults) {
            // مسح بعرض الشجرة (BFS) بدلاً من التعمق في أول بطاقة؛ هذا يوزّع
            // ميزانية العقد على عناصر الشاشة كلها ويقلل احتمال إهمال النتائج اللاحقة.
            val queue = ArrayDeque<Pair<AccessibilityNodeInfo, Int>>()
            queue.add(root to 0) // rootInActiveWindow مملوك للنظام ولا نعيد تدويره
            while (queue.isNotEmpty() && budget[0] < MAX_SEARCH_NODES && text.length < MAX_SEARCH_TEXT) {
                val (node, depth) = queue.removeFirst()
                budget[0]++
                try {
                    if (node.isVisibleToUser && !node.isPassword) {
                        val value = node.text?.toString().orEmpty()
                        val desc = node.contentDescription?.toString().orEmpty()
                        if (value.isNotBlank()) {
                            if (!strongHit && node.isEditable && m.matches(value)) strongHit = true
                            text.append(value).append(' ')
                        }
                        if (desc.isNotBlank()) text.append(desc).append(' ')
                        if (depth < 32 && budget[0] < MAX_SEARCH_NODES && text.length < MAX_SEARCH_TEXT) {
                            for (i in 0 until node.childCount) {
                                val child = node.getChild(i) ?: continue
                                queue.addLast(child to (depth + 1))
                            }
                        }
                    }
                } finally {
                    if (node !== root) try { node.recycle() } catch (_: Throwable) { }
                }
            }
            // إذا وصلنا إلى الحد، لا نترك العقد المتبقية محتجزة.
            while (queue.isNotEmpty()) {
                val remaining = queue.removeFirst().first
                try { remaining.recycle() } catch (_: Throwable) { }
            }
        } else {
            // قبل الإرسال: حقل البحث والاقتراحات فقط، حتى لا نحظر منشورات/محتوى عادي.
            if (field != null) {
                appendNode(field, 0, 3)
                val parent = field.parent
                if (parent != null) {
                    try {
                        val parentIsSearchContainer = isSearchNode(parent) || nodeId(parent).contains("search")
                        for (i in 0 until parent.childCount) {
                            if (budget[0] >= MAX_SEARCH_NODES || text.length >= MAX_SEARCH_TEXT) break
                            val sibling = parent.getChild(i) ?: continue
                            try {
                                val siblingId = nodeId(sibling)
                                val isSuggestion = siblingId.contains("suggest") || siblingId.contains("autocomplete")
                                if (sibling !== field &&
                                    (isSuggestion || (parentIsSearchContainer && sibling.isClickable))
                                ) appendNode(sibling, 0, 8)
                            } finally { try { sibling.recycle() } catch (_: Throwable) { } }
                        }
                    } finally { try { parent.recycle() } catch (_: Throwable) { } }
                }
            }

            // بعض التطبيقات تعرض الاقتراحات في حاوية منفصلة عن حقل البحث.
            fun findSuggestionNodes(node: AccessibilityNodeInfo?, depth: Int) {
                if (node == null || depth > 20 || budget[0] >= MAX_SEARCH_NODES ||
                    text.length >= MAX_SEARCH_TEXT
                ) return
                val id = nodeId(node)
                val label = nodeLabel(node)
                if (id.contains("suggest") || id.contains("autocomplete") ||
                    id.contains("search_suggestion") || label.contains("suggest") ||
                    label.contains("autocomplete") || label.contains("اقتراح")
                ) {
                    appendNode(node, 0, 8)
                    return
                }
                for (i in 0 until node.childCount) {
                    if (budget[0] >= MAX_SEARCH_NODES || text.length >= MAX_SEARCH_TEXT) break
                    val child = node.getChild(i) ?: continue
                    try { findSuggestionNodes(child, depth + 1) }
                    finally { try { child.recycle() } catch (_: Throwable) { } }
                }
            }
            findSuggestionNodes(root, 0)
            try { field?.recycle() } catch (_: Throwable) { }
        }

        val combined = text.toString().take(MAX_SEARCH_TEXT)
        if (combined.isBlank()) return null
        val matched = m.firstMatch(combined) ?: return null
        return strongHit to matched
    }


    private fun findWordFields(root: AccessibilityNodeInfo, m: Words.Matcher, firstOnly: Boolean): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        walkWords(root, m, 0, intArrayOf(0), firstOnly, out)
        return out
    }

    private fun walkWords(
        n: AccessibilityNodeInfo?, m: Words.Matcher, depth: Int, budget: IntArray,
        firstOnly: Boolean, out: MutableList<AccessibilityNodeInfo>
    ) {
        if (n == null || depth > 30 || budget[0] >= 1500) return
        if (firstOnly && out.isNotEmpty()) return
        budget[0]++
        if (!n.isVisibleToUser) return
        // أي نص ظاهر على الشاشة (نص عادي أو خانة إدخال أو وصف عنصر)، عدا حقول كلمات السر
        if (!n.isPassword && (m.matches(n.text) || m.matches(n.contentDescription))) {
            out.add(n)
            if (firstOnly) return
        }
        for (i in 0 until n.childCount) walkWords(n.getChild(i), m, depth + 1, budget, firstOnly, out)
    }

    private fun closeBlockedApp() {
        val pkg = lockedPkg
        // Device Owner can suspend a package; Android applies force-stop-like
        // behavior to it. We then unsuspend it so it can be opened again manually.
        val stopped = pkg?.let { Policy(this).stopPackageTemporarily(it) } == true
        performGlobalAction(GLOBAL_ACTION_HOME)
        handler.postDelayed({
            // Best-effort fallback only: this API alone does not guarantee force-stop.
            if (!stopped && pkg != null) {
                try {
                    getSystemService(android.app.ActivityManager::class.java)
                        .killBackgroundProcesses(pkg)
                } catch (_: Throwable) { }
            }
            lockedPkg = null
            lockedByVisual = false
            pendingKey = null
            hideOverlay()
        }, 1900)
    }

    private fun showOverlay() {
        if (overlay != null) return
        try {
            val v = buildOverlay()
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.OPAQUE
            )
            getSystemService(WindowManager::class.java).addView(v, lp)
            overlay = v
        } catch (_: Throwable) {
            overlay = null
            performGlobalAction(GLOBAL_ACTION_HOME) // إن تعذّر عرض الواجهة نُخرج المستخدم على الأقل
        }
    }

    private fun hideOverlay() {
        val v = overlay ?: return
        overlay = null
        try { getSystemService(WindowManager::class.java).removeView(v) } catch (_: Throwable) { }
    }

    private fun buildOverlay(): View {
        val d = resources.displayMetrics.density
        fun dp(x: Int) = (x * d).toInt()
        fun label(t: String, size: Float, color: Int) = TextView(this).apply {
            text = t; textSize = size; setTextColor(color); gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(8))
        }
        fun button(t: String, onClick: () -> Unit) = Button(this).apply {
            text = t; setTextColor(Color.WHITE); setBackgroundColor(0xFF0F6B57.toInt())
            setOnClickListener { onClick() }
        }
        fun btnParams() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(14) }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(0xFF101418.toInt())
            setPadding(dp(28), dp(28), dp(28), dp(28))
            isClickable = true
            addView(label(getString(if (lockedByVisual) R.string.visual_block_title else R.string.word_block_title), 26f, Color.WHITE))
            addView(label(getString(if (lockedByVisual) R.string.visual_block_msg else R.string.word_block_msg), 16f, 0xFFCCCCCC.toInt()))
            addView(button(getString(R.string.close_app)) { closeBlockedApp() }, btnParams())
        }
    }

    private fun launchBlock(site: Boolean, target: String) = launch(BlockActivity::class.java) {
        putExtra("site", site); putExtra("target", target)
    }

    private fun launchUnlock(mode: String, target: String?) = launch(UnlockActivity::class.java) {
        putExtra("mode", mode); putExtra("target", target)
    }

    private fun launch(cls: Class<*>, extras: Intent.() -> Unit) {
        val t = SystemClock.elapsedRealtime()
        if (t - lastLaunch < 800) return
        lastLaunch = t
        startActivity(
            Intent(this, cls)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NO_ANIMATION)
                .apply(extras)
        )
    }
}
