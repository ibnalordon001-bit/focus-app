package com.focuslock.strict

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

object T {
    const val MIN = 60_000L
    const val HOUR = 60 * MIN
    const val DAY = 24 * HOUR
}

object Strict {
    const val MIN_MS = 3 * T.MIN
    const val MAX_MS = 183 * T.DAY
    const val EXIT_WAIT_MS = 24 * T.HOUR
    const val DEV_GRACE_MS = 72 * T.HOUR   // خيارات المطور تبقى مفتوحة خلال أول 72 ساعة
    /** كلب حراسة: إن ماتت عملية التطبيق (مثلاً بسحبه من الخلفية) يعيد منبّه النظام تشغيل الحماية خلال هذه المدة. */
    const val WATCHDOG_MS = 45_000L

    /** هل ما زالت مهلة الـ72 ساعة قائمة؟ (جلسة بدأت بنسخة قديمة بلا وقت بدء = لا مهلة). */
    fun devGraceActive(p: Prefs): Boolean =
        p.isStrict() && p.strictStartAt > 0 && System.currentTimeMillis() < p.strictStartAt + DEV_GRACE_MS

    /** يطبّق قيد خيارات المطور حسب المهلة. يُستدعى دورياً وعند الإقلاع وعند انتهاء المهلة. */
    fun syncDevOptions(ctx: Context) {
        val p = Prefs(ctx)
        if (!p.isStrict()) return
        val block = !devGraceActive(p)
        if (block != p.devBlocked) {
            Policy(ctx).setDevOptionsBlocked(block)
            p.devBlocked = block
        }
    }

    fun start(ctx: Context, durationMs: Long): Boolean {
        val c = ctx.applicationContext
        val p = Prefs(c)
        if (!p.hasPassword || p.isStrict() || p.strictCleanupPending ||
            durationMs !in MIN_MS..MAX_MS
        ) return false
        // سجلّ مرجعي قبل تفعيل الوضع الصارم: أي حزمة غير موجودة هنا تُعد تثبيتاً جديداً.
        p.registeredPackages = InstallRegistry.currentPackages(c)
        val end = System.currentTimeMillis() + durationMs
        p.strictEndAt = end
        p.strictStartAt = System.currentTimeMillis()
        p.exitRequestedAt = 0
        p.devBlocked = false
        val policy = Policy(c)
        policy.snapshotPlayInstallPolicy(p)
        policy.applyStrict()
        scheduleGrace(c, p.strictStartAt + DEV_GRACE_MS)
        A11y.tryEnable(c)
        schedule(c, end)
        GuardService.start(c)
        scheduleWatchdog(c, WATCHDOG_MS)
        InstallGuardReceiver.startMonitoring(c)
        return true
    }

    fun end(ctx: Context) {
        val c = ctx.applicationContext
        val p = Prefs(c)

        // نعلن انتهاء الجلسة أولاً حتى تتوقف خدمة الوصول عن فرض الحظر فوراً.
        p.strictEndAt = 0
        p.strictCleanupPending = true
        var releaseComplete = false
        try {
            // يجب محاولة تحرير حماية الحزم قبل مسح سجلها.
            releaseComplete = Policy(c).releaseStrict()
        } catch (_: Throwable) {
            // فشل تحرير قيد لا يجوز أن يُبقي حالة التطبيق الداخلية في الوضع الصارم.
        } finally {
            p.strictStartAt = 0
            // لا نمسح سجل الحزم إذا بقي تحرير أي قيد غير مكتمل؛ يمكن إعادة المحاولة لاحقاً.
            if (releaseComplete) {
                p.registeredPackages = emptySet()
                p.strictCleanupPending = false
            }
            p.exitRequestedAt = 0
            p.devBlocked = false

            try { c.getSystemService(AlarmManager::class.java).cancel(pending(c)) } catch (_: Throwable) { }
            try { c.getSystemService(AlarmManager::class.java).cancel(pending(c, 2)) } catch (_: Throwable) { }
            cancelWatchdog(c)
            try { c.stopService(Intent(c, GuardService::class.java)) } catch (_: Throwable) { }
        }
    }

    fun checkExpiry(ctx: Context) {
        val p = Prefs(ctx)
        if (p.strictEndAt > 0 && !p.isStrict()) end(ctx)
    }

    fun schedule(ctx: Context, at: Long) {
        ctx.getSystemService(AlarmManager::class.java)
            .setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending(ctx))
    }

    /**
     * منبّه يوقظ التطبيق ويعيد تشغيل خدمة الحماية وخدمة الوصول إن توقفتا.
     * المنبّهات تبقى حية بعد موت العملية (إلا إذا نفّذ النظام force-stop كاملاً).
     * نستخدم المنبّه الدقيق عند السماح به، وإلا نرجع للمنبّه غير الدقيق.
     */
    fun scheduleWatchdog(ctx: Context, delayMs: Long) {
        val c = ctx.applicationContext
        try {
            val am = c.getSystemService(AlarmManager::class.java)
            val at = System.currentTimeMillis() + delayMs.coerceAtLeast(0L)
            val pi = watchdogPending(c)
            val exactAllowed = Build.VERSION.SDK_INT < Build.VERSION_CODES.S || am.canScheduleExactAlarms()
            try {
                if (exactAllowed) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
                else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            } catch (_: SecurityException) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            }
        } catch (_: Throwable) { /* محاولة بأفضل جهد فقط */ }
    }

    fun cancelWatchdog(ctx: Context) {
        try { ctx.getSystemService(AlarmManager::class.java).cancel(watchdogPending(ctx.applicationContext)) } catch (_: Throwable) { }
    }

    private fun watchdogPending(ctx: Context): PendingIntent = PendingIntent.getBroadcast(
        ctx, 3, Intent(ctx, WatchdogReceiver::class.java),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    fun scheduleGrace(ctx: Context, at: Long) {
        if (at <= System.currentTimeMillis()) return
        ctx.getSystemService(AlarmManager::class.java)
            .setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pending(ctx, 2))
    }

    private fun pending(ctx: Context, code: Int = 1): PendingIntent = PendingIntent.getBroadcast(
        ctx, code, Intent(ctx, ExpiryReceiver::class.java),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )
}

class ExpiryReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Strict.checkExpiry(context)
        Strict.syncDevOptions(context)
    }
}

/** يستيقظ بمنبّه الحراسة: يعيد تشغيل الحماية إن كان الوضع الصارم فعالاً ثم يعيد جدولة نفسه. */
class WatchdogReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val p = Prefs(context)
        Strict.checkExpiry(context)
        if (!p.isStrict()) return
        try { GuardService.start(context) } catch (_: Throwable) { }
        try { if (!A11y.isEnabled(context)) A11y.tryEnable(context) } catch (_: Throwable) { }
        Strict.scheduleWatchdog(context, Strict.WATCHDOG_MS)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        // تحديث FocusLock نفسه ينهي الجلسة الصارمة فوراً، ولا يعيد تفعيلها.
        // أما الإقلاع العادي فيستمر باستعادة الجلسة كما كان سابقاً.
        if (intent.action == Intent.ACTION_MY_PACKAGE_REPLACED) {
            Strict.end(context)
            return
        }

        val p = Prefs(context)
        Strict.checkExpiry(context)
        if (!p.isStrict() && p.strictCleanupPending) {
            // محاولة استكمال تحرير القيود إذا تعذر بعضها أثناء إنهاء الجلسة السابقة.
            Strict.end(context)
        }
        if (p.isStrict()) {
            // توافق مع جلسة قديمة بدأت قبل إضافة سجل التطبيقات.
            if (!p.hasPackageRegistry) p.registeredPackages = InstallRegistry.currentPackages(context)
            // يلتقط إعداد Play إذا كانت الجلسة بدأت بإصدار أقدم، ثم يعيد تطبيق الحماية.
            val policy = Policy(context)
            policy.snapshotPlayInstallPolicy(p)
            policy.applyStrict()
            Strict.schedule(context, p.strictEndAt)
            if (p.strictStartAt > 0) Strict.scheduleGrace(context, p.strictStartAt + Strict.DEV_GRACE_MS)
            Strict.syncDevOptions(context)
            GuardService.start(context)
            Strict.scheduleWatchdog(context, Strict.WATCHDOG_MS)
            InstallGuardReceiver.startMonitoring(context)
        }
    }
}
