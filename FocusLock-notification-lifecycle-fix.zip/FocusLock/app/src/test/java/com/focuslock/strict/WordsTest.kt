package com.focuslock.strict

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class WordsTest {
    @Test fun arabicDiacriticsAndTatweelAreIgnored() {
        val matcher = Words.Matcher(setOf("كتاب"))
        assertTrue(matcher.matches("كِتَاب"))
        assertTrue(matcher.matches("كــتاب"))
    }

    @Test fun taaMarbutaDoesNotCollapseIntoHaa() {
        val matcher = Words.Matcher(setOf("مدرسة"))
        assertTrue(matcher.matches("مدرسة"))
        assertFalse(matcher.matches("مدرسه"))
    }

    @Test fun boundariesPreventSubstringMatches() {
        val matcher = Words.Matcher(setOf("فن"))
        assertTrue(matcher.matches("هذا فن جميل"))
        assertFalse(matcher.matches("فنان"))
    }

    @Test fun ArabicAffixesDoNotTriggerFalsePositives() {
        val matcher = Words.Matcher(setOf("كتاب"))
        assertFalse(matcher.matches("والكتاب"))
        assertFalse(matcher.matches("كتابهم"))
        assertFalse(matcher.matches("كتابك"))
        assertTrue(matcher.matches("كتاب"))
    }

    @Test fun phraseMatchesButSpacedLettersDoNot() {
        assertTrue(Words.Matcher(setOf("محتوى محظور")).matches("هذا محتوى محظور هنا"))
        assertFalse(Words.Matcher(setOf("كلمةطويلة")).matches("ك ل م ة ط و ي ل ة"))
        assertFalse(Words.Matcher(setOf("كلمة")).matches("ك ل م ة"))
    }

    @Test fun arabicPersianCharactersAndInvisibleFormattingAreNormalized() {
        val matcher = Words.Matcher(setOf("كلمة"))
        assertTrue(matcher.matches("کلمة"))
        assertTrue(matcher.matches("ك‏لمة"))
    }

    @Test fun punctuationCanSeparatePhraseWordsButLongGapsDoNot() {
        val matcher = Words.Matcher(setOf("محتوى محظور"))
        assertTrue(matcher.matches("محتوى ـ محظور"))
        assertFalse(matcher.matches("محتوى 123456789 محظور"))
    }

    @Test fun separatedLettersDoNotTriggerFalsePositives() {
        val matcher = Words.Matcher(setOf("كلمةطويلة"))
        assertFalse(matcher.matches("ك ل م ة ط و ي ل ة"))
        assertFalse(matcher.matches("كلمةطويلةجدا"))
    }

    @Test fun englishCaseAndPluralAreSupported() {
        val matcher = Words.Matcher(setOf("BadWord"))
        assertTrue(matcher.matches("badword"))
        assertFalse(matcher.matches("badwords"))
        assertTrue(matcher.matches("badword"))
        assertFalse(matcher.matches("notbadwordish"))
    }

    @Test fun eachLineIsOneKeywordRegardlessOfWordCount() {
        val lines = Words.parseLines("كلمة\nعبارة من عدة كلمات طويلة\nthree word phrase")
        assertTrue(lines.size == 3)
        assertTrue(Words.Matcher(lines.toSet()).matches("هنا عبارة من عدة كلمات طويلة هنا"))
    }

    @Test fun commasAndSemicolonsDoNotSplitALine() {
        val lines = Words.parseLines("alpha, beta; gamma")
        assertTrue(lines.size == 1)
    }

    @Test fun blankAndDuplicateLinesAreIgnored() {
        val lines = Words.parseLines("one\n\n  \nONE\ntwo\r\nthree")
        assertTrue(lines.size == 3)
    }

    @Test fun matcherHasNoTotalLineLimit() {
        val set = (1..Words.MAX_LINES_PER_ADD + 1000).map { "keyword number $it extra" }.toSet()
        val m = Words.Matcher(set)
        assertTrue(m.matches("keyword number 1 extra"))
        assertTrue(m.matches("keyword number ${Words.MAX_LINES_PER_ADD + 1000} extra"))
    }

    @Test fun phraseLinesAreBlockedLikeSingleWords() {
        val m = Words.Matcher(Words.parseLines("كلمة\nعبارة محظورة كاملة").toSet())
        assertTrue(m.matches("كلمة"))
        assertTrue(m.matches("نتائج عبارة محظورة كاملة هنا"))
        assertTrue(m.matches("عبارة - محظورة، كاملة"))
        assertFalse(m.matches("عبارة فقط"))
    }

    @Test fun firstMatchReturnsStableKeyword() {
        val m = Words.Matcher(setOf("عبارة محظورة"))
        assertTrue(m.firstMatch("نتيجة بحث: عبارة محظورة هنا") == "عبارة محظورة")
        assertTrue(m.firstMatch("نص عادي") == null)
    }
}
