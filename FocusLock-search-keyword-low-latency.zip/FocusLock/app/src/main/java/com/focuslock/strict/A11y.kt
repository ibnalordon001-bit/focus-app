package com.focuslock.strict

import android.Manifest
import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager
import android.provider.Settings

object A11y {
    private fun component(ctx: Context) = ComponentName(ctx, GuardAccessibilityService::class.java)

    fun isEnabled(ctx: Context): Boolean {
        val s = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        val me = component(ctx)
        return s.split(':').any { ComponentName.unflattenFromString(it) == me }
    }

    /** يعمل فقط إذا مُنحت WRITE_SECURE_SETTINGS عبر adb. وإلا يرجع false ونفتح شاشة الإعدادات. */
    fun tryEnable(ctx: Context): Boolean {
        if (ctx.checkSelfPermission(Manifest.permission.WRITE_SECURE_SETTINGS) != PackageManager.PERMISSION_GRANTED) {
            return false
        }
        return try {
            val cr = ctx.contentResolver
            if (!isEnabled(ctx)) {
                val cur = Settings.Secure.getString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
                val me = component(ctx).flattenToString()
                Settings.Secure.putString(
                    cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES,
                    if (cur.isBlank()) me else "$cur:$me"
                )
            }
            Settings.Secure.putInt(cr, Settings.Secure.ACCESSIBILITY_ENABLED, 1)
            true
        } catch (_: Exception) {
            false
        }
    }
}
