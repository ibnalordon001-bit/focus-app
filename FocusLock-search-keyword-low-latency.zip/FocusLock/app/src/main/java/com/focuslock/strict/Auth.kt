package com.focuslock.strict

import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

data class AuthResult(val ok: Boolean, val waitSec: Long = 0)

object Auth {
    private const val ITERATIONS = 150_000

    private fun hash(secret: String, salt: ByteArray): ByteArray =
        SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            .generateSecret(PBEKeySpec(secret.toCharArray(), salt, ITERATIONS, 256)).encoded

    fun setPassword(p: Prefs, secret: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        p.passSalt = Base64.encodeToString(salt, Base64.NO_WRAP)
        p.passHash = Base64.encodeToString(hash(secret, salt), Base64.NO_WRAP)
        p.failCount = 0
        p.lockUntil = 0
    }

    /** يتحقق من كلمة السر مع تأخير متصاعد بعد 5 محاولات فاشلة. */
    fun verify(p: Prefs, secret: String): AuthResult {
        val now = System.currentTimeMillis()
        if (now < p.lockUntil) return AuthResult(false, (p.lockUntil - now + 999) / 1000)
        val salt = p.passSalt?.let { Base64.decode(it, Base64.NO_WRAP) } ?: return AuthResult(false)
        val expected = p.passHash?.let { Base64.decode(it, Base64.NO_WRAP) } ?: return AuthResult(false)
        if (MessageDigest.isEqual(expected, hash(secret, salt))) {
            p.failCount = 0
            p.lockUntil = 0
            return AuthResult(true)
        }
        p.failCount += 1
        if (p.failCount >= 5) {
            val wait = minOf(30_000L shl minOf(p.failCount - 5, 7), 3_600_000L)
            p.lockUntil = now + wait
            return AuthResult(false, wait / 1000)
        }
        return AuthResult(false)
    }

    // ---------------- كود الاستعادة ----------------
    // 16 رمزاً عشوائياً من أبجدية من 32 رمزاً (بلا I/O/0/1) = 80 بت. يُحفظ كـ PBKDF2 فقط ولا يمكن استرجاعه.

    private const val CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    private const val CODE_LENGTH = 16

    fun generateRecoveryCode(): String {
        val r = SecureRandom()
        return CharArray(CODE_LENGTH) { CODE_ALPHABET[r.nextInt(CODE_ALPHABET.length)] }
            .concatToString().chunked(4).joinToString("-")
    }

    /** يتجاهل الشرطات والمسافات وحالة الأحرف. */
    fun normalizeCode(input: String): String = input.uppercase().filter { it in CODE_ALPHABET }

    fun setRecoveryCode(p: Prefs, code: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        p.recSalt = Base64.encodeToString(salt, Base64.NO_WRAP)
        p.recHash = Base64.encodeToString(hash(normalizeCode(code), salt), Base64.NO_WRAP)
        p.recFails = 0
        p.recLockUntil = 0
    }

    /** يتحقق من كود الاستعادة بنفس سياسة التأخير المتصاعد بعد 5 محاولات فاشلة. */
    fun verifyRecovery(p: Prefs, code: String): AuthResult {
        val now = System.currentTimeMillis()
        if (now < p.recLockUntil) return AuthResult(false, (p.recLockUntil - now + 999) / 1000)
        val salt = p.recSalt?.let { Base64.decode(it, Base64.NO_WRAP) } ?: return AuthResult(false)
        val expected = p.recHash?.let { Base64.decode(it, Base64.NO_WRAP) } ?: return AuthResult(false)
        if (MessageDigest.isEqual(expected, hash(normalizeCode(code), salt))) {
            p.recFails = 0
            p.recLockUntil = 0
            return AuthResult(true)
        }
        p.recFails += 1
        if (p.recFails >= 5) {
            val wait = minOf(30_000L shl minOf(p.recFails - 5, 7), 3_600_000L)
            p.recLockUntil = now + wait
            return AuthResult(false, wait / 1000)
        }
        return AuthResult(false)
    }
}
