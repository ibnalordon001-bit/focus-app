package com.focuslock.strict

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/** Encrypted export of user configuration only. Password/recovery credentials are deliberately excluded. */
object BackupStore {
    private val MAGIC = byteArrayOf(0x46, 0x4c, 0x42, 0x4b, 0x01) // FLBK + format version
    private const val ITERATIONS = 210_000
    private const val KEY_BITS = 256

    data class Snapshot(
        val blockedApps: Set<String>,
        val lockedApps: Set<String>,
        val blockedSites: Set<String>,
        val blockedWords: Set<String>,
        val keywordApps: Set<String> = emptySet()
    )

    fun export(context: Context, uri: Uri, password: String) {
        require(password.isNotEmpty()) { "أدخل كلمة مرور النسخة الاحتياطية" }
        val prefs = Prefs(context)
        val json = JSONObject().apply {
            put("format", "focuslock-backup")
            put("version", 1)
            put("createdAt", System.currentTimeMillis())
            put("blockedApps", JSONArray(prefs.blockedApps.sorted()))
            put("lockedApps", JSONArray(prefs.lockedApps.sorted()))
            put("blockedSites", JSONArray(prefs.blockedSites.sorted()))
            put("blockedWords", JSONArray(prefs.blockedWords.sorted()))
            put("keywordApps", JSONArray(prefs.keywordApps.sorted()))
        }.toString().toByteArray(Charsets.UTF_8)

        val salt = ByteArray(16).also(SecureRandom()::nextBytes)
        val iv = ByteArray(12).also(SecureRandom()::nextBytes)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, deriveKey(password, salt), GCMParameterSpec(128, iv))
        val encrypted = cipher.doFinal(json)
        val output = ByteArrayOutputStream().apply {
            write(MAGIC); write(salt); write(iv); write(encrypted)
        }.toByteArray()
        context.contentResolver.openOutputStream(uri, "w")?.use { it.write(output) }
            ?: error("تعذّر إنشاء ملف النسخة الاحتياطية")
    }

    fun import(context: Context, uri: Uri, password: String): Snapshot {
        require(password.isNotEmpty()) { "أدخل كلمة مرور النسخة الاحتياطية" }
        val bytes = context.contentResolver.openInputStream(uri)?.use { input ->
            val out = ByteArrayOutputStream()
            val buffer = ByteArray(8192)
            var total = 0
            while (true) {
                val n = input.read(buffer)
                if (n < 0) break
                total += n
                require(total <= 2_000_000) { "حجم ملف النسخة غير صالح" }
                out.write(buffer, 0, n)
            }
            out.toByteArray()
        } ?: error("تعذّر قراءة الملف")

        require(bytes.size > MAGIC.size + 16 + 12 + 16) { "ملف النسخة غير صالح" }
        require(bytes.copyOfRange(0, MAGIC.size).contentEquals(MAGIC)) { "صيغة الملف غير مدعومة" }
        val saltStart = MAGIC.size
        val salt = bytes.copyOfRange(saltStart, saltStart + 16)
        val iv = bytes.copyOfRange(saltStart + 16, saltStart + 28)
        val encrypted = bytes.copyOfRange(saltStart + 28, bytes.size)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, deriveKey(password, salt), GCMParameterSpec(128, iv))
        val plain = cipher.doFinal(encrypted)
        val json = JSONObject(String(plain, Charsets.UTF_8))
        require(json.optString("format") == "focuslock-backup" && json.optInt("version") == 1) {
            "هذا الملف ليس نسخة احتياطية متوافقة من حارس التركيز"
        }
        return Snapshot(
            readSet(json, "blockedApps"),
            readSet(json, "lockedApps"),
            readSet(json, "blockedSites"),
            readSet(json, "blockedWords"),
            readSet(json, "keywordApps")
        )
    }

    private fun readSet(json: JSONObject, key: String): Set<String> {
        val array = json.optJSONArray(key) ?: JSONArray()
        require(array.length() <= 10_000) { "النسخة تحتوي على عناصر كثيرة بشكل غير طبيعي" }
        return buildSet {
            for (i in 0 until array.length()) {
                val value = array.optString(i, "").trim()
                if (value.isNotEmpty() && value.length <= 512) add(value)
            }
        }
    }

    private fun deriveKey(password: String, salt: ByteArray): SecretKeySpec {
        val spec = PBEKeySpec(password.toCharArray(), salt, ITERATIONS, KEY_BITS)
        return try {
            SecretKeySpec(SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded, "AES")
        } finally {
            spec.clearPassword()
        }
    }
}
