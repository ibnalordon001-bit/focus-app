package com.focuslock.strict

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build

/** لقطة بأسماء الحزم المثبتة عند بدء الوضع الصارم. */
object InstallRegistry {
    @Suppress("DEPRECATION")
    fun currentPackages(context: Context): Set<String> {
        val pm = context.packageManager
        val packages = if (Build.VERSION.SDK_INT >= 33) {
            pm.getInstalledPackages(PackageManager.PackageInfoFlags.of(0L))
        } else {
            pm.getInstalledPackages(0)
        }
        return packages.mapNotNull { it.packageName }
            .filter { it != context.packageName }
            .toSet()
    }
}
