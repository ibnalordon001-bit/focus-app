package com.focuslock.strict

/** Normalization and bounded keyword matching for Arabic/English screen text. */
object Words {
    /**
     * الحد الأقصى لعدد الأسطر المسموح إضافتها في كل محاولة إضافة (دفعة واحدة).
     * عدد الأسطر الكلي المحفوظة في القائمة غير محدود.
     */
    const val MAX_LINES_PER_ADD = 5000

    /** كل سطر = كلمة أو عبارة مفتاحية مستقلة. الأسطر الفارغة وغير الصالحة والمكررة تُهمل. */
    fun parseLines(text: String): List<String> =
        text.split(Regex("[\\r\\n\\u0085\\u2028\\u2029]+"))
            .map { it.trim().lowercase() }
            .filter { norm(it).trim().length >= 2 && it.any(Char::isLetter) }
            .distinct()

    fun norm(s: CharSequence): String {
        val src = s.toString().lowercase()
        val out = StringBuilder(src.length)
        for (ch in src) {
            if (ch in '\u064B'..'\u065F' || ch == '\u0670' || ch == '\u0640' ||
                ch in '\u200B'..'\u200F' || ch in '\u202A'..'\u202E' ||
                ch == '\u2060' || ch == '\uFEFF' || ch == '\u00AD') continue
            out.append(when (ch) {
                'أ', 'إ', 'آ', 'ٱ' -> 'ا'
                'ى' -> 'ي'
                'ک' -> 'ك'
                'ی' -> 'ي'
                else -> ch
            })
        }
        return out.toString()
            .replace(Regex("[\\t\\n\\r\\u00A0]+"), " ")
            .replace(Regex(" {2,}"), " ")
    }

    private fun compact(s: String): String = s.filter { it.isLetterOrDigit() }

    class Matcher(words: Set<String>) {
        private data class Entry(val source: String, val needle: String, val regex: Regex?)
        private val entries: List<Entry> = words.asSequence()
            .map { norm(it).trim() }
            .filter { it.length >= 2 && it.any(Char::isLetter) }
            .distinct()
            .map { word ->
                // Conservative matching: require the keyword itself, without inferred
                // Arabic affixes, English plurals, or spaced-letter reconstruction.
                val parts = word.split(Regex("\\s+")).filter(String::isNotEmpty)
                val body = parts.joinToString("[\\p{P}\\p{Z}\\s]{1,3}") {
                    java.util.regex.Pattern.quote(it)
                }
                val pattern = runCatching {
                    Regex("(?<![\\p{L}\\p{N}])$body(?![\\p{L}\\p{N}])")
                }.getOrNull()
                Entry(word, parts.firstOrNull().orEmpty(), pattern)
            }.toList()

        val isEmpty: Boolean get() = entries.isEmpty()

        fun matches(text: CharSequence?): Boolean = firstMatch(text) != null

        /** يرجع الكلمة/العبارة (بعد التطبيع) التي طابقت أولاً، أو null. مفتاح ثابت لتأكيد الحظر. */
        fun firstMatch(text: CharSequence?): String? {
            if (text.isNullOrEmpty() || entries.isEmpty()) return null
            val normalized = norm(text.take(MAX_TEXT))
            if (normalized.isBlank()) return null
            for (entry in entries) {
                // فحص سريع قبل الـ regex حتى تبقى القائمة الكبيرة (آلاف الأسطر) سريعة
                if (entry.needle.isNotEmpty() && !normalized.contains(entry.needle)) continue
                if (entry.regex?.containsMatchIn(normalized) == true) return entry.source
            }
            return null
        }

        companion object { private const val MAX_TEXT = 20_000 }
    }
}
