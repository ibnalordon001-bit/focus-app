# حارس التركيز (FocusLock)

تطبيق أندرويد (Kotlin + Jetpack Compose) لمكافحة التشتيت الرقمي بوضع صارم تحدد مدته من 3 دقائق إلى 183 يوماً.

## البناء
1. ثبّت **Android Studio** (إصدار حديث) ثم: File ← Open ← اختر مجلد المشروع، وانتظر مزامنة Gradle.
2. Build ← Build APK(s). الملف: `app/build/outputs/apk/debug/app-debug.apk`.
3. ثبّت الـAPK على الجوال.

## التفعيل (مرة واحدة)
على جهاز **بدون أي حسابات** (احذف حساب Google مؤقتاً ثم أعده بعد التفعيل)، مع تفعيل تصحيح USB:

```
adb shell dpm set-device-owner com.focuslock.strict/.AdminReceiver
adb shell pm grant com.focuslock.strict android.permission.WRITE_SECURE_SETTINGS
```
ثم افتح التطبيق، أنشئ كلمة السر، وفعّل خدمة إمكانية الوصول (تُفعَّل تلقائياً بعد الأمر الثاني).

> جرّب أولاً بمدة 3 دقائق قبل أي مدة طويلة.

## ما يفعله الوضع الصارم
- حظر التطبيقات والمواقع المختارة (شاشة حظر).
- خيارات المطور تبقى مفتوحة خلال أول 72 ساعة من الوضع الصارم ثم تُحظر. (الجلسات التي بدأت قبل هذه الميزة تُحظر فوراً.)
- منع المستخدم من إلغاء تثبيت التطبيقات الموجودة قبل بدء الوضع الصارم (بحماية فردية لكل حزمة)، مع إبقاء التطبيقات الجديدة قابلة للإزالة تلقائياً.
- **حظر الكلمات المفتاحية**: داخل المتصفحات التي يكتشفها النظام ويوتيوب وإنستغرام فقط. يفحص النصوص التي تكشفها خدمة إمكانية الوصول؛ وبعد تأكيد الكلمة يظهر حاجب ويبقى حتى تضغط «إغلاق التطبيق»، حتى لو اختفت الكلمة أو تغيّرت النافذة. يعمل أثناء الوضع الصارم فقط. لا يكتشف النص الموجود داخل الصور أو العناصر التي لا تكشفها التطبيقات لخدمة إمكانية الوصول.
- طلب كلمة السر قبل شاشات: خيارات المطور، مشرفو الجهاز، إمكانية الوصول، وصفحات التطبيق نفسه.
- طلب كلمة السر قبل فتح أي تطبيق تضيفه لقائمة "المحمية" (يعمل دائماً).
- الهاتف والطوارئ ولوحة المفاتيح والشاشة الرئيسية لا تُحظر أبداً.

## الأمان والمخارج
- كلمة السر: 8 أحرف (3 أنواع) أو PIN من 10 أرقام، مع رفض الضعيف، ومخزّنة كـ PBKDF2 مع تأخير بعد المحاولات الفاشلة.
- **خروج طارئ**: اطلب الخروج، وبعد 24 ساعة تنهي الوضع الصارم بكلمة السر.
- **نسيت كلمة السر**: الطريقة الوحيدة كود استعادة (16 رمزاً) يُعرض مرة واحدة عند إنشاء كلمة السر ويُحفظ كـ PBKDF2 فقط. إن ضاع الكود فلا توجد أي طريقة. إعادة التعيين بالكود لا تُنهي الوضع الصارم، والخروج الطارئ يبقى بانتظار 24 ساعة وكلمة السر. يمكن إنشاء كود جديد من الإعدادات بعد إدخال كلمة السر.
- أثناء الوضع الصارم لا يمكن حذف عناصر من القوائم، فقط الإضافة.
- لإزالة صلاحية المالك بعد الانتهاء: زر "إزالة صلاحية مالك الجهاز" داخل التطبيق.

## حدود معروفة
- حظر المواقع يقرأ شريط عنوان المتصفح عبر Accessibility، ويدعم المتصفحات الشائعة، وقد يتأثر بتحديثات المتصفح.
- حماية شاشات الإعدادات تعتمد على عناوين الشاشات (عربي/إنجليزي) وقد تختلف بين الشركات المصنّعة. عدّل `Guard.SENSITIVE_KEYWORDS` عند الحاجة.
- Recovery/Flash للجهاز خارج سيطرة أي تطبيق.
- في أجهزة Xiaomi/Huawei/Oppo اسمح للتطبيق بالتشغيل التلقائي واستثنه من توفير البطارية.

## تغييرات التطوير الإضافية

- تم تحديث ألوان الواجهة والبطاقات الرئيسية وهوية أيقونة التطبيق.
- تمت إضافة تصدير واستيراد قوائم المستخدم (التطبيقات المحظورة، التطبيقات المقفلة، المواقع والكلمات المحظورة) في ملف مشفّر AES-GCM.
- مفتاح تشفير النسخة مشتق من كلمة المرور باستخدام PBKDF2-HMAC-SHA256. يلزم إدخال كلمة المرور نفسها عند الاسترجاع.
- لا تتضمن النسخة كلمة مرور التطبيق أو hash/salt أو كود الاستعادة أو بيانات الوضع الصارم.
- النسخ والاسترجاع متاحان خارج الوضع الصارم فقط.

### سياسة تثبيت التطبيقات وتحديثها أثناء الوضع الصارم

- تُسجّل الحزم الموجودة لحظة بدء الوضع الصارم وتُحمى كل واحدة منها عبر `setUninstallBlocked`، بدلاً من قيد `DISALLOW_UNINSTALL_APPS` العام الذي كان يمنع التطبيق نفسه من إزالة الحزم الجديدة.
- يسمح مراقب الحزم بتحديث الحزم المسجلة فقط عندما يكون الحدث استبدالاً (`EXTRA_REPLACING`) ومصدر التثبيت Google Play (`com.android.vending`).
- أي تطبيق جديد يكتمل تثبيته رغم القيود يُعلّق ثم يرسل التطبيق طلب إلغاء تثبيته. هذه معالجة احتياطية بعد التثبيت وليست منعاً مسبقاً لتطبيقات Play الجديدة.
- لمنع التثبيت والتحديث من المصادر الخارجية، يفعّل الوضع الصارم `DISALLOW_INSTALL_UNKNOWN_SOURCES` وإعداد Google Play المُدار `verify_apps:device_wide_unknown_source_block` على مستوى الجهاز. يتطلب هذا الإعداد Google Play إصدار 80812500 أو أحدث؛ الإصدارات الأقدم تتجاهله. إذا تعذر تطبيقه، يبقى قيد المصادر غير الموثوقة العادي فقط.
- تحديثات Google Play للتطبيقات المسجلة لا تتأثر بحماية إلغاء التثبيت الفردية.
- بعد انتهاء الوضع الصارم، تُرفع الحماية الفردية وتُستعاد قيمة إعداد Google Play السابقة.

**حدود يجب اختبارها على الجهاز:** تثبيت تطبيق جديد من Play يُكتشف بعد اكتمال التثبيت ثم تُطلب إزالته؛ لذلك لا يمكن ضمان منع ظهوره لحظياً. كما أن المتاجر المصنفة من النظام كمصادر موثوقة قد تختلف معاملتها حسب إصدار أندرويد والشركة المصنّعة. لا يُعد السلوك مضموناً قبل اختبار حالات التثبيت والتحديث على الجهاز الفعلي.

### Install guard behavior

During strict mode, newly added packages are suspended when Android permits it and submitted for removal through `PackageInstaller`. Removal is verified against `PackageManager`; pending packages are retried with backoff and checked again by a periodic installed-package sweep. Packages recorded before strict mode are preserved. Android may still refuse removal of protected/system packages, so this mechanism is best-effort rather than an absolute guarantee for every package.

## Visual content guard

During Strict Mode, supported browsers are visually sampled continuously; selected ordinary apps are sampled only during detected search sessions. Android 11+ screenshot capture is performed by the existing AccessibilityService. Inference is fully local using the FocusLock-trained MobileNetV2 TFLite model (outputs: `nudity`, `sexy`), bundled in `app/src/main/assets/`:

- `focuslock_visual_model.tflite`  (requires LiteRT >= 2.1; app uses com.google.ai.edge.litert:litert:2.1.6)
- `classification_thresholds.json` (nudity 0.9753, sexy 0.9796)
- `model_metadata.json` (reference only)

At load time the app verifies the model's SHA-256 against a value pinned in `VisualNsfwClassifier.kt`, checks the TFLite signature and tensor layout (input `[1,224,224,3]` float32 0..255, output `[1,2]`), and reads the thresholds. A class with an invalid threshold never blocks. If an asset is missing or invalid, the visual guard is disabled and does not block anything. `nudity` blocks immediately; `sexy` needs two consecutive hits. Screenshots are never uploaded.

The training dataset (`onullusoy/harmful-contents`) is research / non-commercial only and has no separate labels for bikini, body-emphasis, or dance. This is a baseline model; validate false-positive/false-negative rates and speed on the target device before relying on it. See `MODEL-ATTRIBUTION.txt`.

### Body detector (NudeNet, optional)
If `app/src/main/assets/nudenet_320n_640_fp16.tflite` is present, each screenshot is also run through NudeNet (full screen + top/bottom halves).
- Exposed explicit parts (breast, genitalia, anus, buttocks) at score >= 0.55 -> immediate block.
- Provocative covered parts (breast/buttocks/genitalia covered) or exposed belly at score >= 0.60 -> block after two consecutive hits.
Constants are in `NudeNetDetector.kt` (`EXPLICIT_THRESHOLD`, `REVEALING_THRESHOLD`, `EXPLICIT`, `REVEALING`). Check Logcat tag `FocusLockVisual` for scores, and tune on your own screenshots. It detects exposed/covered body parts, not "modesty"; beach/gym photos may be blocked. AGPL-3.0 applies (see MODEL-ATTRIBUTION.txt).
