package com.focuslock.strict

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Rect
import android.util.Log
import com.google.ai.edge.litert.DataType
import com.google.ai.edge.litert.Interpreter
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.min

/**
 * Optional second model: NudeNet v3 (320n, YOLOv8n, AGPL-3.0) converted to TFLite.
 * Expected asset: assets/nudenet_320n_640_fp16.tflite  (input 640x640 RGB 0..1, 18 classes).
 * If the asset is missing or its tensors are not as expected, this detector stays disabled.
 * Only the best score per class is used (no box decoding / NMS is needed for block decisions).
 */
internal class NudeNetDetector(context: Context) {

    /** Highest score seen per class, indexed like [LABELS]. */
    class Result(val best: FloatArray) {
        fun score(label: String): Float = best[LABELS.indexOf(label)]
        fun maxOf(vararg labels: String): Float = labels.maxOf { score(it) }
    }

    private val appContext = context.applicationContext
    @Volatile private var interpreter: Interpreter? = null
    @Volatile private var lastLoadAttempt = 0L
    private var nhwc = true
    private var channelsFirst = true
    private var size = INPUT_SIZE
    private lateinit var outShape: IntArray

    /** Returns null when the model is unavailable. Does not recycle [source]. */
    fun detect(source: Bitmap): Result? {
        val model = load() ?: return null
        return try {
            val best = FloatArray(LABELS.size)
            val w = source.width
            val h = source.height
            // Full screen, plus top and bottom halves for better resolution of small pictures.
            val regions = listOf(Rect(0, 0, w, h), Rect(0, 0, w, h / 2), Rect(0, h / 2, w, h))
            for (r in regions) {
                if (r.width() < 32 || r.height() < 32) continue
                runRegion(model, source, r, best)
            }
            Result(best)
        } catch (t: Throwable) {
            Log.e(TAG, "detect failed", t)
            null
        }
    }

    private fun runRegion(model: Interpreter, source: Bitmap, r: Rect, best: FloatArray) {
        val canvasBmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(canvasBmp)
        canvas.drawColor(Color.rgb(114, 114, 114))
        val scale = min(size.toFloat() / r.width(), size.toFloat() / r.height())
        val dw = (r.width() * scale).toInt().coerceAtLeast(1)
        val dh = (r.height() * scale).toInt().coerceAtLeast(1)
        val dst = Rect((size - dw) / 2, (size - dh) / 2, (size - dw) / 2 + dw, (size - dh) / 2 + dh)
        canvas.drawBitmap(source, r, dst, null)
        val pixels = IntArray(size * size)
        canvasBmp.getPixels(pixels, 0, size, 0, 0, size, size)
        canvasBmp.recycle()

        val input = ByteBuffer.allocateDirect(size * size * 3 * 4).order(ByteOrder.nativeOrder())
        if (nhwc) {
            for (p in pixels) {
                input.putFloat(((p shr 16) and 0xFF) / 255f)
                input.putFloat(((p shr 8) and 0xFF) / 255f)
                input.putFloat((p and 0xFF) / 255f)
            }
        } else {
            for (shift in intArrayOf(16, 8, 0)) for (p in pixels) input.putFloat(((p shr shift) and 0xFF) / 255f)
        }
        input.rewind()

        val a = outShape[1]
        val b = outShape[2]
        val out = Array(1) { Array(a) { FloatArray(b) } }
        model.run(input, out)
        val o = out[0]
        val n = if (channelsFirst) b else a
        for (i in 0 until n) {
            for (c in LABELS.indices) {
                val v = if (channelsFirst) o[4 + c][i] else o[i][4 + c]
                if (v > best[c]) best[c] = v
            }
        }
    }

    private fun load(): Interpreter? {
        interpreter?.let { return it }
        val now = System.currentTimeMillis()
        if (now - lastLoadAttempt < 60_000L) return null
        lastLoadAttempt = now
        val file = File(appContext.filesDir, MODEL_FILE)
        return try {
            try { appContext.assets.open(MODEL_ASSET).close() } catch (_: Throwable) {
                Log.i(TAG, "NudeNet asset not bundled: body detector disabled"); return null
            }
            appContext.assets.open(MODEL_ASSET).use { i -> FileOutputStream(file).use { o -> i.copyTo(o) } }
            val m = Interpreter(file, Interpreter.Options().apply { setNumThreads(2) })
            val inT = m.getInputTensor(0)
            val outT = m.getOutputTensor(0)
            val ins = inT.shape()
            val outs = outT.shape()
            val okIn = inT.dataType() == DataType.FLOAT32 && ins.size == 4 && ins[0] == 1 &&
                ((ins[1] == ins[2] && ins[3] == 3) || (ins[1] == 3 && ins[2] == ins[3]))
            val okOut = outT.dataType() == DataType.FLOAT32 && outs.size == 3 && outs[0] == 1 &&
                (outs[1] == 4 + LABELS.size || outs[2] == 4 + LABELS.size)
            if (!okIn || !okOut) {
                Log.e(TAG, "unexpected NudeNet tensors in=${ins.toList()} out=${outs.toList()}")
                m.close(); return null
            }
            nhwc = ins[3] == 3
            size = if (nhwc) ins[1] else ins[2]
            channelsFirst = outs[1] == 4 + LABELS.size
            outShape = outs
            Log.i(TAG, "NudeNet loaded in=${ins.toList()} out=${outs.toList()}")
            interpreter = m
            m
        } catch (t: Throwable) {
            Log.e(TAG, "NudeNet load failed: body detector DISABLED", t)
            null
        }
    }

    fun close() { try { interpreter?.close() } catch (_: Throwable) { }; interpreter = null }

    companion object {
        private const val TAG = "FocusLockVisual"
        private const val MODEL_ASSET = "nudenet_320n_640_fp16.tflite"
        private const val MODEL_FILE = "nudenet_320n.tflite"
        private const val INPUT_SIZE = 640

        // Class order of NudeNet v3 (must match the model).
        val LABELS = listOf(
            "FEMALE_GENITALIA_COVERED", "FACE_FEMALE", "BUTTOCKS_EXPOSED", "FEMALE_BREAST_EXPOSED",
            "FEMALE_GENITALIA_EXPOSED", "MALE_BREAST_EXPOSED", "ANUS_EXPOSED", "FEET_EXPOSED",
            "BELLY_COVERED", "FEET_COVERED", "ARMPITS_COVERED", "ARMPITS_EXPOSED", "FACE_MALE",
            "BELLY_EXPOSED", "MALE_GENITALIA_EXPOSED", "ANUS_COVERED", "FEMALE_BREAST_COVERED",
            "BUTTOCKS_COVERED",
        )

        // ---- Decision rules (tune on your own screenshots) ----
        /** Explicit anatomy: blocks immediately at this score. */
        const val EXPLICIT_THRESHOLD = 0.55f
        /** Revealing/provocative-but-covered body parts: needs two consecutive hits. */
        const val REVEALING_THRESHOLD = 0.60f
        val EXPLICIT = arrayOf("FEMALE_BREAST_EXPOSED", "FEMALE_GENITALIA_EXPOSED", "MALE_GENITALIA_EXPOSED",
            "ANUS_EXPOSED", "BUTTOCKS_EXPOSED")
        val REVEALING = arrayOf("FEMALE_BREAST_COVERED", "BUTTOCKS_COVERED", "FEMALE_GENITALIA_COVERED",
            "BELLY_EXPOSED")
    }
}
