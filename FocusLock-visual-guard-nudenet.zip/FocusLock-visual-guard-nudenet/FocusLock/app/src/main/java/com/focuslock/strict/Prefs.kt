package com.focuslock.strict

import android.content.Context

class Prefs(context: Context) {
    private val sp = context.applicationContext.getSharedPreferences("focuslock", Context.MODE_PRIVATE)

    var passHash: String?
        get() = sp.getString("hash", null)
        set(v) { sp.edit().putString("hash", v).apply() }
    var passSalt: String?
        get() = sp.getString("salt", null)
        set(v) { sp.edit().putString("salt", v).apply() }
    var strictEndAt: Long
        get() = sp.getLong("strictEnd", 0L)
        set(v) { sp.edit().putLong("strictEnd", v).apply() }
    var strictStartAt: Long
        get() = sp.getLong("strictStart", 0L)
        set(v) { sp.edit().putLong("strictStart", v).apply() }
    /** يبقى مفعلاً إذا احتاج تحرير قيود الوضع الصارم إلى إعادة محاولة. */
    var strictCleanupPending: Boolean
        get() = sp.getBoolean("strictCleanupPending", false)
        set(v) { sp.edit().putBoolean("strictCleanupPending", v).apply() }
    /** آخر حالة طبّقناها لقيد خيارات المطور (true = محظورة). */
    var devBlocked: Boolean
        get() = sp.getBoolean("devBlocked", false)
        set(v) { sp.edit().putBoolean("devBlocked", v).apply() }
    var exitRequestedAt: Long
        get() = sp.getLong("exitAt", 0L)
        set(v) { sp.edit().putLong("exitAt", v).apply() }
    var recHash: String?
        get() = sp.getString("recHash", null)
        set(v) { sp.edit().putString("recHash", v).apply() }
    var recSalt: String?
        get() = sp.getString("recSalt", null)
        set(v) { sp.edit().putString("recSalt", v).apply() }
    var recFails: Int
        get() = sp.getInt("recFails", 0)
        set(v) { sp.edit().putInt("recFails", v).apply() }
    var recLockUntil: Long
        get() = sp.getLong("recLock", 0L)
        set(v) { sp.edit().putLong("recLock", v).apply() }
    var graceUntil: Long
        get() = sp.getLong("grace", 0L)
        set(v) { sp.edit().putLong("grace", v).apply() }
    var lockUntil: Long
        get() = sp.getLong("lockUntil", 0L)
        set(v) { sp.edit().putLong("lockUntil", v).apply() }
    var failCount: Int
        get() = sp.getInt("fails", 0)
        set(v) { sp.edit().putInt("fails", v).apply() }

    /** الحالة السابقة لإعداد Google Play الذي يمنع التثبيت من خارج المتجر أثناء الوضع الصارم. */
    var playUnknownSourcesSnapshotTaken: Boolean
        get() = sp.getBoolean("playUnknownSourcesSnapshotTaken", false)
        set(v) { sp.edit().putBoolean("playUnknownSourcesSnapshotTaken", v).apply() }
    var playUnknownSourcesWasPresent: Boolean
        get() = sp.getBoolean("playUnknownSourcesWasPresent", false)
        set(v) { sp.edit().putBoolean("playUnknownSourcesWasPresent", v).apply() }
    var playUnknownSourcesPreviousValue: Boolean
        get() = sp.getBoolean("playUnknownSourcesPreviousValue", false)
        set(v) { sp.edit().putBoolean("playUnknownSourcesPreviousValue", v).apply() }

    /** حزم التطبيقات التي كانت مثبتة عند بدء الوضع الصارم. */
    var registeredPackages: Set<String>
        get() = getSet("registeredPackages")
        set(v) = putSet("registeredPackages", v)
    val hasPackageRegistry: Boolean
        get() = sp.contains("registeredPackages")

    /** حزم جديدة قيد الإزالة؛ تبقى مسجلة حتى نتأكد من اختفائها فعلياً. */
    var pendingRemovals: Set<String>
        get() = getSet("pendingRemovals")
        private set(v) = putSet("pendingRemovals", v)

    fun addPendingRemoval(packageName: String): Boolean {
        val current = pendingRemovals
        if (packageName in current) return false
        pendingRemovals = current + packageName
        return true
    }

    fun removePendingRemoval(packageName: String) {
        pendingRemovals = pendingRemovals - packageName
    }

    /** تدرّج فاصل إعادة المحاولة: دقيقة، 5 دقائق، ثم 15 دقيقة كحد أعلى. */
    fun nextRemovalRetryDelay(packageName: String): Long {
        val key = "removalRetry:$packageName"
        val attempt = sp.getInt(key, 0) + 1
        sp.edit().putInt(key, attempt).apply()
        return when {
            attempt <= 1 -> 60_000L
            attempt == 2 -> 5 * 60_000L
            else -> 15 * 60_000L
        }
    }

    fun clearRemovalRetry(packageName: String) {
        sp.edit().remove("removalRetry:$packageName").apply()
    }

    var blockedApps: Set<String>
        get() = getSet("blockedApps")
        set(v) = putSet("blockedApps", v)
    var lockedApps: Set<String>
        get() = getSet("lockedApps")
        set(v) = putSet("lockedApps", v)
    var blockedSites: Set<String>
        get() = getSet("blockedSites")
        set(v) = putSet("blockedSites", v)
    var blockedWords: Set<String>
        get() = getSet("blockedWords")
        set(v) = putSet("blockedWords", v)
    /** التطبيقات التي يختارها المستخدم لتطبيق حظر الكلمات المفتاحية داخلها. */
    var keywordApps: Set<String>
        get() = getSet("keywordApps")
        set(v) = putSet("keywordApps", v)

    val hasPassword: Boolean get() = passHash != null
    val hasRecovery: Boolean get() = recHash != null
    fun isStrict(): Boolean = strictEndAt > System.currentTimeMillis()

    private fun getSet(k: String): Set<String> = sp.getStringSet(k, emptySet())?.toSet() ?: emptySet()
    private fun putSet(k: String, v: Set<String>) { sp.edit().putStringSet(k, HashSet(v)).apply() }
}
