package com.focuslock.strict

import android.content.Context
import android.graphics.Bitmap
import android.util.Log
import com.google.ai.edge.litert.DataType
import com.google.ai.edge.litert.Interpreter
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

/**
 * Local-only visual moderation using the FocusLock-trained MobileNetV2 model.
 * The model and its thresholds are bundled in app assets:
 *   assets/focuslock_visual_model.tflite        (input [1,224,224,3] float32 0..255)
 *   assets/classification_thresholds.json       ({"nudity": x, "sexy": y})
 * Screenshots are never uploaded. If either asset is missing, invalid, or its
 * SHA-256 does not match the pinned value, the classifier stays disabled (returns null) and never blocks.
 *
 * Model output order: nudity, sexy (independent sigmoid probabilities).
 */
internal class VisualNsfwClassifier(context: Context) {
    data class Scores(
        val nudity: Float,
        val sexy: Float,
        /** True only when the class has a calibrated threshold (validation precision target met). */
        val nudityBlocks: Boolean,
        val sexyBlocks: Boolean,
        /** From the NudeNet body detector (false when that model is not bundled). */
        val bodyExplicit: Boolean = false,
        val bodyRevealing: Boolean = false,
    )

    private class Thresholds(val nudity: Float, val sexy: Float, val sha256: String)

    private val appContext = context.applicationContext
    private val executor = Executors.newSingleThreadExecutor()
    @Volatile private var interpreter: Interpreter? = null
    @Volatile private var lastLoadAttempt = 0L
    @Volatile private var thresholds: Thresholds? = null
    private val bodyDetector = NudeNetDetector(context)

    fun analyze(bitmap: Bitmap, callback: (Scores?) -> Unit) {
        try {
            executor.execute {
                var result: Scores? = null
                try {
                    val model = getInterpreter()
                    val base = if (model != null) classifyTiles(model, bitmap) else null
                    val body = bodyDetector.detect(bitmap)
                    if (base != null || body != null) {
                        val bx = body != null && body.maxOf(*NudeNetDetector.EXPLICIT) >= NudeNetDetector.EXPLICIT_THRESHOLD
                        val br = body != null && body.maxOf(*NudeNetDetector.REVEALING) >= NudeNetDetector.REVEALING_THRESHOLD
                        result = (base ?: Scores(0f, 0f, false, false)).copy(bodyExplicit = bx, bodyRevealing = br)
                        Log.d(TAG, "scores nudity=%.3f sexy=%.3f block=%s/%s body=%s/%s".format(
                            result.nudity, result.sexy, result.nudityBlocks, result.sexyBlocks, bx, br))
                    }
                } catch (t: Throwable) {
                    Log.e(TAG, "analyze failed", t)
                    result = null
                } finally {
                    try { bitmap.recycle() } catch (_: Throwable) { }
                }
                callback(result)
            }
        } catch (_: Throwable) {
            try { bitmap.recycle() } catch (_: Throwable) { }
            callback(null)
        }
    }

    private fun getInterpreter(): Interpreter? {
        interpreter?.let { return it }
        val now = System.currentTimeMillis()
        if (now - lastLoadAttempt < 60_000L) return null
        lastLoadAttempt = now
        val file = File(appContext.filesDir, MODEL_FILE)
        return try {
            val th = readThresholds() ?: return null
            // Copy bundled asset to private storage and verify its SHA-256 against the training export.
            val digest = java.security.MessageDigest.getInstance("SHA-256")
            file.parentFile?.mkdirs()
            val tmp = File(file.parentFile, "$MODEL_FILE.part")
            appContext.assets.open(MODEL_ASSET).use { input ->
                FileOutputStream(tmp).use { output ->
                    val buffer = ByteArray(64 * 1024)
                    var total = 0L
                    while (true) {
                        val count = input.read(buffer)
                        if (count < 0) break
                        total += count
                        if (total > MAX_MODEL_BYTES) throw IllegalStateException("Model too large")
                        digest.update(buffer, 0, count)
                        output.write(buffer, 0, count)
                    }
                    output.fd.sync()
                }
            }
            val actual = digest.digest().joinToString("") { "%02x".format(it) }
            if (!actual.equals(th.sha256, ignoreCase = true) || tmp.length() < MIN_MODEL_BYTES) {
                Log.e(TAG, "model rejected: sha256 mismatch ($actual) or too small")
                tmp.delete()
                return null
            }
            if (file.exists()) file.delete()
            if (!tmp.renameTo(file)) {
                tmp.copyTo(file, overwrite = true)
                tmp.delete()
            }
            // Reject unexpected model variants before inference (TFL3 signature + tensor layout).
            val signature = ByteArray(4)
            java.io.RandomAccessFile(file, "r").use { raf ->
                if (raf.length() < 8L) throw IllegalStateException("Invalid model")
                raf.seek(4L)
                raf.readFully(signature)
            }
            if (!signature.contentEquals(byteArrayOf(0x54, 0x46, 0x4C, 0x33))) {
                Log.e(TAG, "bad TFLite signature")
                file.delete()
                return null
            }
            val options = Interpreter.Options().apply { setNumThreads(2) }
            val loaded = Interpreter(file, options)
            val inputTensor = loaded.getInputTensor(0)
            val outputTensor = loaded.getOutputTensor(0)
            val input = inputTensor.shape()
            val output = outputTensor.shape()
            if (inputTensor.dataType() != DataType.FLOAT32 || outputTensor.dataType() != DataType.FLOAT32 ||
                !input.contentEquals(intArrayOf(1, 224, 224, 3)) ||
                output.size != 2 || output[0] != 1 || output[1] != 2
            ) {
                Log.e(TAG, "unexpected tensors in=${input.toList()} out=${output.toList()}")
                loaded.close()
                file.delete()
                return null
            }
            Log.i(TAG, "model loaded OK; thresholds nudity=${th.nudity} sexy=${th.sexy}")
            thresholds = th
            interpreter = loaded
            loaded
        } catch (t: Throwable) {
            Log.e(TAG, "model load failed: visual guard DISABLED", t)
            try { file.delete() } catch (_: Throwable) { }
            null
        }
    }

    /** Reads thresholds from assets/classification_thresholds.json. An invalid value disables auto-block for that class. */
    private fun readThresholds(): Thresholds? {
        val text = appContext.assets.open(THRESHOLDS_ASSET).bufferedReader(Charsets.UTF_8).use { it.readText() }
        val json = org.json.JSONObject(text)
        fun valid(name: String): Float {
            val v = json.optDouble(name, 2.0).toFloat()
            return if (v in 0.5f..1.0f) v else Float.MAX_VALUE
        }
        return Thresholds(valid("nudity"), valid("sexy"), EXPECTED_SHA256)
    }

    /** Six overlapping square crops ensure smaller cards are not lost in a full-screen resize. */
    private fun classifyTiles(model: Interpreter, source: Bitmap): Scores {
        val width = source.width
        val height = source.height
        val side = min((width * 0.74f).toInt(), (height * 0.34f).toInt()).coerceAtLeast(224)
            .coerceAtMost(min(width, height))
        val maxX = (width - side).coerceAtLeast(0)
        val maxY = (height - side).coerceAtLeast(0)
        val xs = intArrayOf(0, maxX)
        val ys = intArrayOf(0, maxY / 2, maxY)
        var nudity = 0f
        var sexy = 0f
        for (y in ys) for (x in xs) {
            val crop = Bitmap.createBitmap(source, x, y, side, side)
            val scaled = Bitmap.createScaledBitmap(crop, 224, 224, true)
            if (scaled !== crop) crop.recycle()
            val input = ByteBuffer.allocateDirect(224 * 224 * 3 * 4).order(ByteOrder.nativeOrder())
            val pixels = IntArray(224 * 224)
            scaled.getPixels(pixels, 0, 224, 0, 0, 224, 224)
            scaled.recycle()
            for (pixel in pixels) {
                // The exported model normalizes internally: raw RGB values in 0..255.
                input.putFloat(((pixel shr 16) and 0xFF).toFloat())
                input.putFloat(((pixel shr 8) and 0xFF).toFloat())
                input.putFloat((pixel and 0xFF).toFloat())
            }
            input.rewind()
            val output = Array(1) { FloatArray(2) }
            model.run(input, output)
            nudity = max(nudity, output[0][0])
            sexy = max(sexy, output[0][1])
        }
        val th = thresholds
        return Scores(
            nudity, sexy,
            nudityBlocks = th != null && nudity >= th.nudity,
            sexyBlocks = th != null && sexy >= th.sexy,
        )
    }

    fun close() {
        try {
            executor.execute {
                try { interpreter?.close() } catch (_: Throwable) { }
                bodyDetector.close()
                interpreter = null
                executor.shutdown()
            }
        } catch (_: Throwable) { }
    }

    companion object {
        private const val TAG = "FocusLockVisual"
        private const val MODEL_FILE = "focuslock_visual_model.tflite"
        private const val MODEL_ASSET = "focuslock_visual_model.tflite"
        private const val THRESHOLDS_ASSET = "classification_thresholds.json"
        // Integrity pin for the bundled model (sha256 of focuslock_visual_model.tflite).
        private const val EXPECTED_SHA256 = "8b8dc28c7c55835e1f568db9bae19cb56e1ec2600e34eb6f046eeb8b4f1f4da9"
        private const val MIN_MODEL_BYTES = 1L * 1024L * 1024L
        private const val MAX_MODEL_BYTES = 25L * 1024L * 1024L
    }
}
