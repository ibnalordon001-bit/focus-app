package com.focuslock.strict

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.Bitmap
import android.os.Build
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.Display
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * يرصد التطبيق/الموقع/الشاشة في المقدمة:
 *  - أثناء الوضع الصارم: يحظر التطبيقات والمواقع المختارة، ويحمي شاشات الإعدادات الحساسة بكلمة السر.
 *  - دائماً: يطلب كلمة السر قبل فتح التطبيقات المحمية.
 */
class GuardAccessibilityService : AccessibilityService() {
    private val prefs by lazy { Prefs(this) }
    private var safe: Set<String> = emptySet()
    private var browsers: Set<String> = emptySet()
    // المتصفحات تُراقب تلقائياً، حتى لو ثُبّتت بعد تفعيل الوضع الصارم.
    private var wordBrowsers: Set<String> = emptySet()
    private var refreshedAt = 0L
    private var lastForegroundPkg: String? = null
    private var lastLaunch = 0L
    private var lastSiteCheck = 0L
    private var lastSettingsCheck = 0L

    // ---- حظر الكلمات المفتاحية ----
    private val handler = Handler(Looper.getMainLooper())
    private var overlay: View? = null
    private var lockedPkg: String? = null
    private var lockedByVisual = false
    private var pendingKey: String? = null
    private var pendingSince = 0L
    private var scanPending = false
    private var scanDueAt = 0L
    private var matcherWords: Set<String> = emptySet()
    private var matcher = Words.Matcher(emptySet())
    // جلسة البحث لا تبدأ إلا عند التفاعل مع حقل بحث حقيقي، وتنتهي عند مغادرة سياقه.
    private var searchPkg: String? = null
    private var searchQuery: String = ""
    private var searchSubmitted = false
    private var searchResultTransitionSeen = false
    private var searchLastSignal = 0L

    // ---- الفحص البصري المحلي ----
    private val visualClassifierDelegate = lazy { VisualNsfwClassifier(this) }
    private val visualClassifier by visualClassifierDelegate
    private val visualCaptureExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private var visualCaptureInFlight = false
    private var lastVisualCaptureAt = 0L
    private var visualEvidencePackage: String? = null
    private var visualHitStreak = 0
    private val scanRunnable = Runnable {
        scanPending = false
        scanDueAt = 0L
        try { checkWords() } catch (_: Throwable) { /* لا نترك الخدمة تنهار */ }
    }

    // لا نعتمد على وصول حدث جديد فقط: افحص النافذة الحالية دورياً، خصوصاً
    // عند تفعيل الوضع الصارم والخدمة متصلة بالفعل أو عند ضياع حدث من النظام.
    private val foregroundPoll = object : Runnable {
        override fun run() {
            try {
                val root = rootInActiveWindow
                val pkg = root?.packageName?.toString()
                if (!pkg.isNullOrBlank()) {
                    val event = AccessibilityEvent.obtain(AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED)
                    event.packageName = pkg
                    // الفحص الدوري يحافظ على حماية المقدمة، لكنه لا يشغّل مسح الكلمات؛
                    // مراقبة البحث تعتمد على أحداث Accessibility الفعلية.
                    try { handle(event, fromForegroundPoll = true) } finally { event.recycle() }
                }
            } catch (_: Throwable) { /* لا نترك الفحص الدوري يُسقط الخدمة */ }
            handler.postDelayed(this, FOREGROUND_POLL_MS)
        }
    }

    companion object {
        private const val FOREGROUND_POLL_MS = 1_000L
        private const val MAX_SEARCH_NODES = 1800
        private const val MAX_SEARCH_TEXT = 24000
        private const val VISUAL_CAPTURE_INTERVAL_MS = 1_400L
    }

    private val sensitiveAll by lazy {
        Guard.SENSITIVE_KEYWORDS +
            listOf("سهولة الوصول", "خيارات المطوّر", "للمطورين", "device manager").map { it.lowercase() } +
            listOf(getString(R.string.app_name), getString(R.string.service_label)).map { it.lowercase() }
    }
    private val devWords by lazy { Guard.DEV_KEYWORDS.map { it.lowercase() }.toSet() }
    private val sensitiveNoDev by lazy { sensitiveAll.filter { it !in devWords } }

    /** خلال أول 72 ساعة من الوضع الصارم لا نحمي شاشة خيارات المطور. */
    private fun sensitive(): List<String> = if (Strict.devGraceActive(prefs)) sensitiveNoDev else sensitiveAll

    override fun onServiceConnected() {
        super.onServiceConnected()
        refresh()
        handler.removeCallbacks(foregroundPoll)
        // افحص التطبيق الظاهر فور اتصال الخدمة، ثم استمر بالفحص كل ثانية.
        foregroundPoll.run()
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacks(scanRunnable)
        handler.removeCallbacks(foregroundPoll)
        if (visualClassifierDelegate.isInitialized()) visualClassifier.close()
        visualCaptureExecutor.shutdownNow()
        hideOverlay()
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        try { handle(event) } catch (_: Throwable) { /* لا نترك الخدمة تنهار أبداً */ }
    }

    private fun refresh() {
        safe = Guard.protectedPackages(this)
        browsers = Guard.browserPackages(this)
        wordBrowsers = Guard.realBrowserPackages(this)
        refreshedAt = SystemClock.elapsedRealtime()
    }

    private fun handle(e: AccessibilityEvent?, fromForegroundPoll: Boolean = false) {
        val pkg = e?.packageName?.toString() ?: return
        // القفل المؤكد لا يسقط بتبديل النافذة أو فتح الإشعارات أو الشاشة الرئيسية.
        if (lockedPkg != null) {
            if (!prefs.isStrict() || (!lockedByVisual && currentMatcher().isEmpty)) {
                lockedPkg = null
                lockedByVisual = false
                pendingKey = null
                hideOverlay()
            } else {
                if (overlay == null) showOverlay()
                return
            }
        }
        if (pkg == packageName) {
            // فتح FocusLock نفسه يعني مغادرة سياق البحث؛ لا نُبقِي جلسة قديمة
            // نشطة إذا عاد المستخدم لاحقاً إلى التطبيق المستهدف.
            if (searchPkg != null) resetSearchSession()
            return
        }
        val now = SystemClock.elapsedRealtime()
        val stateChange = e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
        // عند فتح تطبيق جديد نعيد اكتشاف المتصفحات، حتى نلتقط المتصفح المثبّت حديثاً.
        val newForeground = stateChange && pkg != lastForegroundPkg
        if (newForeground) lastForegroundPkg = pkg
        if (now - refreshedAt > 120_000 || (newForeground && pkg !in wordBrowsers)) refresh()
        if (prefs.strictEndAt > 0 && !prefs.isStrict()) Strict.end(this)
        if (pkg in safe) return

        val strict = prefs.isStrict()

        if (strict && inWordScope(pkg) && !fromForegroundPoll) {
            watchWords(e)
            // لا نكمل فحوصات هذه النافذة بعد تثبيت حظر الكلمة.
            if (lockedPkg != null) return
        } else if (searchPkg != null && pkg != searchPkg && stateChange) {
            // لا ننهي جلسة البحث بسبب أحداث لوحة المفاتيح (Gboard مثلاً).
            // ننهيها فقط عندما تصبح نافذة تطبيق آخر هي النافذة النشطة فعلياً.
            val activePkg = rootInActiveWindow?.packageName?.toString()
            if (!activePkg.isNullOrBlank() && activePkg != searchPkg && activePkg == pkg) {
                resetSearchSession()
            }
        }

        if (strict && (pkg in wordBrowsers || (pkg in prefs.keywordApps && searchPkg == pkg))) {
            requestVisualCapture(pkg)
        }

        if (strict && pkg in prefs.blockedApps) { launchBlock(site = false, target = pkg); return }

        if (stateChange && pkg in prefs.lockedApps &&
            (Guard.appGrace[pkg] ?: 0L) < System.currentTimeMillis()
        ) { launchUnlock("app", pkg); return }

        if (!strict) return

        if (pkg in browsers) {
            if (now - lastSiteCheck > 400) { lastSiteCheck = now; checkBrowser(pkg) }
            return
        }
        if (pkg in Guard.SETTINGS) {
            if (System.currentTimeMillis() > prefs.graceUntil && now - lastSettingsCheck > 300) {
                lastSettingsCheck = now
                if ((stateChange && isSensitive(e)) || titleSensitive()) launchUnlock("settings", null)
            }
        }
    }

    /** يقرأ نصوص أعلى الشاشة (العنوان) ويتجاهل صفوف القوائم القابلة للضغط. */
    private fun titleSensitive(): Boolean {
        val root = rootInActiveWindow ?: return false
        if (root.packageName?.toString() !in Guard.SETTINGS) return false
        return scanTitles(root, 0, resources.displayMetrics.heightPixels * 0.30)
    }

    private fun scanTitles(n: AccessibilityNodeInfo?, depth: Int, limit: Double): Boolean {
        if (n == null || depth > 15) return false
        val txt = n.text?.toString()?.lowercase()
        if (!txt.isNullOrEmpty() && !n.isClickable && n.parent?.isClickable != true &&
            n.parent?.parent?.isClickable != true && sensitive().any { txt.contains(it) }
        ) {
            val r = Rect()
            n.getBoundsInScreen(r)
            if (r.top < limit && r.bottom > 0) return true
        }
        for (i in 0 until n.childCount) if (scanTitles(n.getChild(i), depth + 1, limit)) return true
        return false
    }

    private fun isSensitive(e: AccessibilityEvent): Boolean {
        val text = ((e.text?.joinToString(" ") ?: "") + " " + (e.className ?: "")).lowercase()
        return sensitive().any { text.contains(it) }
    }

    private fun checkBrowser(pkg: String) {
        val sites = prefs.blockedSites
        if (sites.isEmpty()) return
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != pkg) return
        val url = findUrl(root, pkg) ?: return
        val host = Guard.normalizeDomain(url) ?: return
        if (Guard.isBlocked(host, sites)) launchBlock(site = true, target = host)
    }

    private fun findUrl(root: AccessibilityNodeInfo, pkg: String): String? {
        Guard.URL_BAR_IDS[pkg]?.forEach { id ->
            val t = root.findAccessibilityNodeInfosByViewId(id).firstOrNull()?.text
            if (!t.isNullOrBlank()) return t.toString()
        }
        return scan(root, 0) // متصفح غير معروف: نبحث عن حقل نص يشبه شريط العنوان
    }

    private fun scan(n: AccessibilityNodeInfo?, depth: Int): String? {
        if (n == null || depth > 12) return null
        val id = n.viewIdResourceName.orEmpty().lowercase()
        val looksLikeBar = n.className?.contains("EditText") == true ||
            id.contains("url") || id.contains("omnibox") || id.contains("address")
        if (looksLikeBar && !n.text.isNullOrBlank()) return n.text.toString()
        for (i in 0 until n.childCount) scan(n.getChild(i), depth + 1)?.let { return it }
        return null
    }

    // ======================= حظر الكلمات المفتاحية =======================

    private fun currentMatcher(): Words.Matcher {
        val w = prefs.blockedWords
        if (w != matcherWords) { matcherWords = w; matcher = Words.Matcher(w) }
        return matcher
    }

    /** كل المتصفحات تُراقب تلقائياً؛ اختيار المستخدم مطلوب للتطبيقات العادية فقط. */
    private fun inWordScope(pkg: String): Boolean = pkg in wordBrowsers || pkg in prefs.keywordApps

    /** لا تبدأ الرقابة إلا داخل سياق البحث، وتشمل الكتابة والاقتراحات والنتائج. */
    private fun watchWords(e: AccessibilityEvent) {
        val m = currentMatcher()
        val pkg = e.packageName?.toString() ?: return
        // Visual protection has its own search-session tracking and remains active
        // even when the user has not configured any blocked keywords.
        if (m.isEmpty) {
            updateVisualSearchSession(e, pkg)
            if (searchPkg == pkg) requestVisualCapture(pkg)
            return
        }

        // المسار الأسرع: افحص العنصر الذي أرسل حدث الكتابة قبل طلب شجرة الواجهة.
        // لا نعدّ أي EditText حقل بحث؛ يجب أن يحمل هو أو أحد آبائه دلالة بحث.
        val source = e.source
        val sourceId = source?.viewIdResourceName.orEmpty().lowercase()
        val sourceLabel = ((source?.hintText?.toString().orEmpty()) + " " +
            (source?.text?.toString().orEmpty()) + " " +
            (source?.contentDescription?.toString().orEmpty())).lowercase()
        val sourceText = source?.text?.toString().orEmpty()
        val directSearchSource = source != null && isSearchFieldSource(source)
        val submitAction = e.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED &&
            (sourceId.contains("search") || sourceId.contains("submit") || sourceId.contains("suggest") ||
                sourceLabel.contains("search") || sourceLabel.contains("بحث") || sourceLabel.contains("enter") ||
                sourceLabel.contains("go"))
        try {
            if (directSearchSource &&
                (e.eventType == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED ||
                    e.eventType == AccessibilityEvent.TYPE_VIEW_FOCUSED) &&
                source != null && source.isEditable && !source.isPassword && m.matches(sourceText)) {
                searchPkg = pkg
                searchLastSignal = SystemClock.elapsedRealtime()
                searchQuery = sourceText
                searchSubmitted = false
                searchResultTransitionSeen = false
                lockKeyword(pkg)
                return
            }
        } finally {
            source?.recycle()
        }

        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != pkg) return
        val field = findSearchField(root)

        if (field != null) {
            searchPkg = pkg
            searchLastSignal = SystemClock.elapsedRealtime()
            val value = field.text?.toString().orEmpty()
            if (value.isNotBlank()) searchQuery = value
            // لا نلغي حالة إرسال البحث لمجرد أن حقل البحث ما زال موجوداً.
            // نبدأ بحثاً جديداً فقط عند عودة المستخدم فعلياً للكتابة أو تركيز الحقل.
            if (e.eventType == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED ||
                (e.eventType == AccessibilityEvent.TYPE_VIEW_FOCUSED && field.isFocused)) {
                searchSubmitted = false
                searchResultTransitionSeen = false
            }
            // بعض التطبيقات تبقي مربع البحث أعلى صفحة النتائج؛ فقدانه للتركيز
            // مع تغيّر محتوى النافذة بعد وجود عبارة بحث يعني أن النتائج بدأت بالظهور.
            if (searchQuery.isNotBlank() && !field.isFocused &&
                e.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {
                searchSubmitted = true
            }
        }
        if (submitAction && searchPkg == pkg) {
            searchSubmitted = true
            searchResultTransitionSeen = false
            searchLastSignal = SystemClock.elapsedRealtime()
        }

        val now = SystemClock.elapsedRealtime()
        val hasSearchMarkers = hasSearchUiMarkers(root)
        if (searchPkg == pkg && hasSearchMarkers) searchLastSignal = now

        // عند انتقال المستخدم إلى شاشة أخرى داخل التطبيق، لا نُبقي الرقابة فعالة
        // إلا إذا بقيت عناصر واجهة البحث/الاقتراحات/النتائج ظاهرة.
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && field == null &&
            !hasSearchMarkers && !submitAction) {
            if (searchSubmitted && !searchResultTransitionSeen) {
                // أول انتقال بعد إرسال البحث هو غالباً ظهور صفحة النتائج نفسها.
                searchResultTransitionSeen = true
            } else {
                // انتقال لاحق إلى شاشة أخرى داخل التطبيق يعني مغادرة سياق النتائج.
                resetSearchSession()
                return
            }
        }
        if (searchPkg != pkg) return
        if (!searchSubmitted && now - searchLastSignal > 12_000 && field == null && !hasSearchMarkers) {
            resetSearchSession()
            return
        }
        if (field == null && !hasSearchMarkers && !searchSubmitted) return
        scheduleScan(if (e.eventType == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED) 0 else 100)
    }

    /** Search-only visual scope for selected ordinary apps, independent of keyword lists. */
    private fun updateVisualSearchSession(e: AccessibilityEvent, pkg: String) {
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != pkg) return
        val field = findSearchField(root)
        val markers = hasSearchUiMarkers(root)
        val source = e.source
        val sourceId = source?.viewIdResourceName.orEmpty().lowercase()
        val sourceLabel = ((source?.hintText?.toString().orEmpty()) + " " +
            (source?.text?.toString().orEmpty()) + " " +
            (source?.contentDescription?.toString().orEmpty())).lowercase()
        val submitAction = e.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED &&
            (sourceId.contains("search") || sourceId.contains("submit") || sourceId.contains("suggest") ||
                sourceLabel.contains("search") || sourceLabel.contains("بحث") || sourceLabel.contains("enter") ||
                sourceLabel.contains("go"))
        try {
            if (field != null) {
                searchPkg = pkg
                searchLastSignal = SystemClock.elapsedRealtime()
                val value = field.text?.toString().orEmpty()
                if (value.isNotBlank()) searchQuery = value
                if (e.eventType == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED ||
                    (e.eventType == AccessibilityEvent.TYPE_VIEW_FOCUSED && field.isFocused)) {
                    searchSubmitted = false
                    searchResultTransitionSeen = false
                }
                if (searchQuery.isNotBlank() && !field.isFocused &&
                    e.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {
                    searchSubmitted = true
                }
            }
            if (submitAction && searchPkg == pkg) {
                searchSubmitted = true
                searchResultTransitionSeen = false
                searchLastSignal = SystemClock.elapsedRealtime()
            }
        } finally {
            try { source?.recycle() } catch (_: Throwable) { }
        }
        val now = SystemClock.elapsedRealtime()
        if (searchPkg == pkg && markers) searchLastSignal = now
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && field == null &&
            !markers && !submitAction
        ) {
            if (searchSubmitted && !searchResultTransitionSeen) {
                searchResultTransitionSeen = true
            } else {
                resetSearchSession()
                return
            }
        }
        if (!searchSubmitted && now - searchLastSignal > 12_000L && field == null && !markers) {
            resetSearchSession()
        }
    }

    private fun isVisualScopeActive(pkg: String): Boolean =
        pkg in wordBrowsers || (pkg in prefs.keywordApps && searchPkg == pkg)

    /** Captures the visible display at a conservative cadence; inference runs off the UI thread. */
    private fun requestVisualCapture(pkg: String) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R || !prefs.isStrict() ||
            lockedPkg != null || !isVisualScopeActive(pkg)
        ) return
        val now = SystemClock.elapsedRealtime()
        if (visualCaptureInFlight || now - lastVisualCaptureAt < VISUAL_CAPTURE_INTERVAL_MS) return
        visualCaptureInFlight = true
        lastVisualCaptureAt = now
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, visualCaptureExecutor,
                object : AccessibilityService.TakeScreenshotCallback {
                    override fun onSuccess(screenshot: AccessibilityService.ScreenshotResult) {
                        var bitmap: Bitmap? = null
                        val hardware = screenshot.hardwareBuffer
                        try {
                            val wrapped = Bitmap.wrapHardwareBuffer(hardware, screenshot.colorSpace)
                            bitmap = wrapped?.copy(Bitmap.Config.ARGB_8888, false)
                        } catch (_: Throwable) {
                        } finally {
                            try { hardware.close() } catch (_: Throwable) { }
                        }
                        val captured = bitmap
                        if (captured == null) {
                            handler.post { visualCaptureInFlight = false }
                            return
                        }
                        visualClassifier.analyze(captured) { scores ->
                            handler.post {
                                visualCaptureInFlight = false
                                if (scores != null && pkg == rootInActiveWindow?.packageName?.toString() &&
                                    prefs.isStrict() && isVisualScopeActive(pkg) && lockedPkg == null
                                ) evaluateVisualScores(pkg, scores)
                            }
                        }
                    }

                    override fun onFailure(errorCode: Int) {
                        handler.post { visualCaptureInFlight = false }
                    }
                })
        } catch (_: Throwable) {
            visualCaptureInFlight = false
        }
    }

    /** Explicit imagery is blocked immediately; suggestive imagery needs repeat confirmation. */
    private fun evaluateVisualScores(pkg: String, scores: VisualNsfwClassifier.Scores) {
        if (visualEvidencePackage != pkg) {
            visualEvidencePackage = pkg
            visualHitStreak = 0
        }
        val explicitHit = scores.explicit >= 0.94f
        val suggestiveHit = scores.suggestive >= 0.88f && scores.neutral <= 0.18f
        if (explicitHit) {
            visualHitStreak = 2
        } else if (suggestiveHit) {
            visualHitStreak++
        } else {
            visualHitStreak = 0
        }
        if (visualHitStreak >= 2) {
            lockedPkg = pkg
            lockedByVisual = true
            pendingKey = null
            visualHitStreak = 0
            showOverlay()
        }
    }

    private fun resetSearchSession() {
        searchPkg = null
        searchQuery = ""
        searchSubmitted = false
        searchResultTransitionSeen = false
        searchLastSignal = 0L
        visualEvidencePackage = null
        visualHitStreak = 0
        pendingKey = null
        handler.removeCallbacks(scanRunnable)
        scanPending = false
        scanDueAt = 0L
    }

    private fun nodeId(n: AccessibilityNodeInfo?): String = n?.viewIdResourceName.orEmpty().lowercase()
    private fun nodeLabel(n: AccessibilityNodeInfo?): String =
        ((n?.hintText?.toString().orEmpty()) + " " +
            (n?.contentDescription?.toString().orEmpty())).lowercase()

    private fun isSearchNode(n: AccessibilityNodeInfo): Boolean {
        val id = nodeId(n)
        val label = nodeLabel(n)
        return id.contains("search") || id.contains("query") || id.contains("autocomplete") ||
            label.contains("search") || label.contains("بحث") || label.contains("ابحث")
    }

    /** يتحقق من أن مصدر الحدث حقل بحث أو تابع لحاوية بحث معروفة. */
    private fun isSearchFieldSource(source: AccessibilityNodeInfo): Boolean {
        if (!source.isVisibleToUser || !source.isEditable || source.isPassword) return false
        var node: AccessibilityNodeInfo? = source
        var depth = 0
        while (node != null && depth++ < 6) {
            if (isSearchNode(node)) return true
            node = node.parent
        }
        return false
    }

    private fun lockKeyword(pkg: String) {
        lockedPkg = pkg
        lockedByVisual = false
        pendingKey = null
        handler.removeCallbacks(scanRunnable)
        scanPending = false
        scanDueAt = 0L
        showOverlay()
    }

    private fun findSearchField(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var visited = 0
        while (queue.isNotEmpty() && visited++ < 900) {
            val n = queue.removeFirst()
            if (n.isVisibleToUser && !n.isPassword && n.isEditable && isSearchNode(n)) return n
            for (i in 0 until n.childCount) n.getChild(i)?.let(queue::addLast)
        }
        return null
    }

    private fun hasSearchUiMarkers(root: AccessibilityNodeInfo): Boolean {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var visited = 0
        while (queue.isNotEmpty() && visited++ < 900) {
            val n = queue.removeFirst()
            if (n.isVisibleToUser) {
                val id = nodeId(n)
                if (id.contains("search") || id.contains("suggest") || id.contains("autocomplete") ||
                    id.contains("search_result") || id.contains("searchresult")) return true
            }
            for (i in 0 until n.childCount) n.getChild(i)?.let(queue::addLast)
        }
        return false
    }

    private fun scheduleScan(delayMs: Long) {
        val dueAt = SystemClock.uptimeMillis() + delayMs.coerceAtLeast(0L)
        // Keep the earliest requested scan. A text-edit event (0 ms) must not
        // wait behind an older, slower content-change scan (500 ms).
        if (scanPending && dueAt >= scanDueAt) return
        if (scanPending) handler.removeCallbacks(scanRunnable)
        scanPending = true
        scanDueAt = dueAt
        handler.postAtTime(scanRunnable, dueAt)
    }

    /** قفل ثابت بعد تأكيد الكلمة، مع تأكيد ثانٍ للنصوص غير القابلة للتحرير. */
    private fun checkWords() {
        val m = currentMatcher()
        if (!prefs.isStrict() || (m.isEmpty && !lockedByVisual)) {
            lockedPkg = null
            lockedByVisual = false
            pendingKey = null
            hideOverlay()
            return
        }
        // لا نعتمد على rootInActiveWindow بعد الحظر؛ قد يصبح null أو يشير إلى
        // المشغّل/الستارة، وهذا لا ينبغي أن يرفع القفل.
        if (lockedPkg != null) { showOverlay(); return }

        val root = rootInActiveWindow ?: return
        val pkg = root.packageName?.toString() ?: return
        if (pkg == packageName || pkg in safe || !inWordScope(pkg)) return

        if (searchPkg != pkg) return
        val scan = collectSearchContextText(root, m, searchSubmitted)
        if (scan == null) { pendingKey = null; return }
        val (hit, sample) = scan
        val key = sample.take(120)
        val now = SystemClock.elapsedRealtime()
        val strong = hit?.isEditable == true
        // نص خانة البحث يُحظر فوراً؛ الاقتراح/النتيجة يلزم ظهورها في فحصين متتاليين.
        if (strong || (key.isNotEmpty() && key == pendingKey && now - pendingSince >= 90)) {
            lockedPkg = pkg
            pendingKey = null
            showOverlay()
        } else {
            if (key != pendingKey) {
                pendingKey = key
                pendingSince = now
            }
            scheduleScan(90)
        }
    }

    /** يجمع نص البحث والاقتراحات؛ وبعد الإرسال يفحص كامل شجرة الشاشة الظاهرة. */
    private fun collectSearchContextText(
        root: AccessibilityNodeInfo, m: Words.Matcher, includeResults: Boolean
    ): Pair<AccessibilityNodeInfo?, String>? {
        val text = StringBuilder()
        var strongHit: AccessibilityNodeInfo? = null
        val budget = intArrayOf(0)
        // لا نبحث عن الحقل بعد الإرسال؛ نمسح الشاشة مباشرة من الجذر لتقليل التأخير.
        val field = if (includeResults) null else findSearchField(root)

        fun appendNode(node: AccessibilityNodeInfo?, depth: Int, maxDepth: Int) {
            if (node == null || depth > maxDepth || budget[0] >= MAX_SEARCH_NODES ||
                text.length >= MAX_SEARCH_TEXT
            ) return
            budget[0]++
            if (!node.isVisibleToUser || node.isPassword) return

            val value = node.text?.toString().orEmpty()
            val desc = node.contentDescription?.toString().orEmpty()
            if (value.isNotBlank()) {
                if (strongHit == null && node.isEditable && m.matches(value)) strongHit = node
                text.append(value).append(' ')
            }
            if (desc.isNotBlank()) text.append(desc).append(' ')
            for (i in 0 until node.childCount) {
                if (budget[0] >= MAX_SEARCH_NODES || text.length >= MAX_SEARCH_TEXT) break
                appendNode(node.getChild(i), depth + 1, maxDepth)
            }
        }

        if (includeResults) {
            // بعد إرسال البحث نمسح الشجرة مرة واحدة من الجذر؛ لا نستهلك الميزانية
            // أولاً في الحقل والاقتراحات، حتى لا تُترك بقية بطاقات النتائج دون فحص.
            appendNode(root, 0, 32)
        } else {
            // قبل الإرسال: حقل البحث والاقتراحات فقط، حتى لا نحظر منشورات/محتوى عادي.
            if (field != null) {
                appendNode(field, 0, 3)
                val parent = field.parent
                if (parent != null) {
                    val parentIsSearchContainer = isSearchNode(parent) || nodeId(parent).contains("search")
                    for (i in 0 until parent.childCount) {
                        if (budget[0] >= MAX_SEARCH_NODES || text.length >= MAX_SEARCH_TEXT) break
                        val sibling = parent.getChild(i)
                        val siblingId = nodeId(sibling)
                        val isSuggestion = siblingId.contains("suggest") || siblingId.contains("autocomplete")
                        if (sibling != null && sibling !== field &&
                            (isSuggestion || (parentIsSearchContainer && sibling.isClickable))
                        ) appendNode(sibling, 0, 8)
                    }
                }
            }

            // بعض التطبيقات تعرض الاقتراحات في حاوية منفصلة عن حقل البحث.
            fun findSuggestionNodes(node: AccessibilityNodeInfo?, depth: Int) {
                if (node == null || depth > 20 || budget[0] >= MAX_SEARCH_NODES ||
                    text.length >= MAX_SEARCH_TEXT
                ) return
                val id = nodeId(node)
                if (id.contains("suggest") || id.contains("autocomplete") ||
                    id.contains("search_suggestion")
                ) {
                    appendNode(node, 0, 8)
                    return
                }
                for (i in 0 until node.childCount) {
                    if (budget[0] >= MAX_SEARCH_NODES || text.length >= MAX_SEARCH_TEXT) break
                    findSuggestionNodes(node.getChild(i), depth + 1)
                }
            }
            findSuggestionNodes(root, 0)
        }

        val combined = text.toString().take(MAX_SEARCH_TEXT)
        if (combined.isBlank() || !m.matches(combined)) return null
        return strongHit to combined
    }


    private fun findWordFields(root: AccessibilityNodeInfo, m: Words.Matcher, firstOnly: Boolean): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        walkWords(root, m, 0, intArrayOf(0), firstOnly, out)
        return out
    }

    private fun walkWords(
        n: AccessibilityNodeInfo?, m: Words.Matcher, depth: Int, budget: IntArray,
        firstOnly: Boolean, out: MutableList<AccessibilityNodeInfo>
    ) {
        if (n == null || depth > 30 || budget[0] >= 1500) return
        if (firstOnly && out.isNotEmpty()) return
        budget[0]++
        if (!n.isVisibleToUser) return
        // أي نص ظاهر على الشاشة (نص عادي أو خانة إدخال أو وصف عنصر)، عدا حقول كلمات السر
        if (!n.isPassword && (m.matches(n.text) || m.matches(n.contentDescription))) {
            out.add(n)
            if (firstOnly) return
        }
        for (i in 0 until n.childCount) walkWords(n.getChild(i), m, depth + 1, budget, firstOnly, out)
    }

    private fun closeBlockedApp() {
        val pkg = lockedPkg
        // Device Owner can suspend a package; Android applies force-stop-like
        // behavior to it. We then unsuspend it so it can be opened again manually.
        val stopped = pkg?.let { Policy(this).stopPackageTemporarily(it) } == true
        performGlobalAction(GLOBAL_ACTION_HOME)
        handler.postDelayed({
            // Best-effort fallback only: this API alone does not guarantee force-stop.
            if (!stopped && pkg != null) {
                try {
                    getSystemService(android.app.ActivityManager::class.java)
                        .killBackgroundProcesses(pkg)
                } catch (_: Throwable) { }
            }
            lockedPkg = null
            lockedByVisual = false
            pendingKey = null
            hideOverlay()
        }, 1900)
    }

    private fun showOverlay() {
        if (overlay != null) return
        try {
            val v = buildOverlay()
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.OPAQUE
            )
            getSystemService(WindowManager::class.java).addView(v, lp)
            overlay = v
        } catch (_: Throwable) {
            overlay = null
            performGlobalAction(GLOBAL_ACTION_HOME) // إن تعذّر عرض الواجهة نُخرج المستخدم على الأقل
        }
    }

    private fun hideOverlay() {
        val v = overlay ?: return
        overlay = null
        try { getSystemService(WindowManager::class.java).removeView(v) } catch (_: Throwable) { }
    }

    private fun buildOverlay(): View {
        val d = resources.displayMetrics.density
        fun dp(x: Int) = (x * d).toInt()
        fun label(t: String, size: Float, color: Int) = TextView(this).apply {
            text = t; textSize = size; setTextColor(color); gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(8))
        }
        fun button(t: String, onClick: () -> Unit) = Button(this).apply {
            text = t; setTextColor(Color.WHITE); setBackgroundColor(0xFF0F6B57.toInt())
            setOnClickListener { onClick() }
        }
        fun btnParams() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(14) }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(0xFF101418.toInt())
            setPadding(dp(28), dp(28), dp(28), dp(28))
            isClickable = true
            addView(label(getString(if (lockedByVisual) R.string.visual_block_title else R.string.word_block_title), 26f, Color.WHITE))
            addView(label(getString(if (lockedByVisual) R.string.visual_block_msg else R.string.word_block_msg), 16f, 0xFFCCCCCC.toInt()))
            addView(button(getString(R.string.close_app)) { closeBlockedApp() }, btnParams())
        }
    }

    private fun launchBlock(site: Boolean, target: String) = launch(BlockActivity::class.java) {
        putExtra("site", site); putExtra("target", target)
    }

    private fun launchUnlock(mode: String, target: String?) = launch(UnlockActivity::class.java) {
        putExtra("mode", mode); putExtra("target", target)
    }

    private fun launch(cls: Class<*>, extras: Intent.() -> Unit) {
        val t = SystemClock.elapsedRealtime()
        if (t - lastLaunch < 800) return
        lastLaunch = t
        startActivity(
            Intent(this, cls)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NO_ANIMATION)
                .apply(extras)
        )
    }
}
