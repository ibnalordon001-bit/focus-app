package com.focuslock.strict

import android.content.Context
import android.graphics.Bitmap
import org.tensorflow.lite.DataType
import org.tensorflow.lite.Interpreter
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.Executors
import kotlin.math.max
import kotlin.math.min

/**
 * Local-only visual moderation. The model is downloaded once over HTTPS and kept
 * in the app's private files directory. Screenshots are never uploaded.
 *
 * Model output order: drawings, hentai, neutral, porn, sexy.
 */
internal class VisualNsfwClassifier(context: Context) {
    data class Scores(val explicit: Float, val suggestive: Float, val neutral: Float)

    private val appContext = context.applicationContext
    private val executor = Executors.newSingleThreadExecutor()
    @Volatile private var interpreter: Interpreter? = null
    @Volatile private var lastLoadAttempt = 0L

    fun analyze(bitmap: Bitmap, callback: (Scores?) -> Unit) {
        try {
            executor.execute {
                var result: Scores? = null
                try {
                    val model = getInterpreter()
                    if (model != null) result = classifyTiles(model, bitmap)
                } catch (_: Throwable) {
                    result = null
                } finally {
                    try { bitmap.recycle() } catch (_: Throwable) { }
                }
                callback(result)
            }
        } catch (_: Throwable) {
            try { bitmap.recycle() } catch (_: Throwable) { }
            callback(null)
        }
    }

    private fun getInterpreter(): Interpreter? {
        interpreter?.let { return it }
        val now = System.currentTimeMillis()
        if (now - lastLoadAttempt < 60_000L) return null
        lastLoadAttempt = now
        val file = File(appContext.filesDir, MODEL_FILE)
        return try {
            if (!file.exists() || file.length() !in MIN_MODEL_BYTES..MAX_MODEL_BYTES) {
                file.parentFile?.mkdirs()
                val tmp = File(file.parentFile, "$MODEL_FILE.part")
                downloadModel(tmp)
                if (tmp.length() !in MIN_MODEL_BYTES..MAX_MODEL_BYTES) {
                    tmp.delete()
                    return null
                }
                if (file.exists()) file.delete()
                if (!tmp.renameTo(file)) {
                    tmp.copyTo(file, overwrite = true)
                    tmp.delete()
                }
            }
            // Reject HTML/error payloads and unexpected model variants before inference.
            val signature = ByteArray(4)
            java.io.RandomAccessFile(file, "r").use { raf ->
                if (raf.length() < 8L) throw IllegalStateException("Invalid model")
                raf.seek(4L)
                raf.readFully(signature)
            }
            if (!signature.contentEquals(byteArrayOf(0x54, 0x46, 0x4C, 0x33))) {
                file.delete()
                return null
            }
            val options = Interpreter.Options().apply { setNumThreads(2) }
            val loaded = Interpreter(file, options)
            val inputTensor = loaded.getInputTensor(0)
            val outputTensor = loaded.getOutputTensor(0)
            val input = inputTensor.shape()
            val output = outputTensor.shape()
            if (inputTensor.dataType() != DataType.FLOAT32 || outputTensor.dataType() != DataType.FLOAT32 ||
                !input.contentEquals(intArrayOf(1, 224, 224, 3)) ||
                output.size != 2 || output[0] != 1 || output[1] != 5
            ) {
                loaded.close()
                file.delete()
                return null
            }
            interpreter = loaded
            loaded
        } catch (_: Throwable) {
            try { file.delete() } catch (_: Throwable) { }
            null
        }
    }

    private fun downloadModel(destination: File) {
        val connection = (URL(MODEL_URL).openConnection() as HttpURLConnection).apply {
            connectTimeout = 20_000
            readTimeout = 45_000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "FocusLock-VisualGuard/1.0")
        }
        try {
            connection.connect()
            if (connection.responseCode !in 200..299) throw IllegalStateException("Model download failed")
            connection.inputStream.use { input ->
                FileOutputStream(destination).use { output ->
                    val buffer = ByteArray(64 * 1024)
                    var total = 0L
                    while (true) {
                        val count = input.read(buffer)
                        if (count < 0) break
                        total += count
                        if (total > MAX_DOWNLOAD_BYTES) throw IllegalStateException("Model too large")
                        output.write(buffer, 0, count)
                    }
                    output.fd.sync()
                }
            }
        } finally {
            connection.disconnect()
        }
    }

    /** Six overlapping square crops ensure smaller cards are not lost in a full-screen resize. */
    private fun classifyTiles(model: Interpreter, source: Bitmap): Scores {
        val width = source.width
        val height = source.height
        val side = min((width * 0.74f).toInt(), (height * 0.34f).toInt()).coerceAtLeast(224)
            .coerceAtMost(min(width, height))
        val maxX = (width - side).coerceAtLeast(0)
        val maxY = (height - side).coerceAtLeast(0)
        val xs = intArrayOf(0, maxX)
        val ys = intArrayOf(0, maxY / 2, maxY)
        var explicit = 0f
        var suggestive = 0f
        var neutral = 0f
        for (y in ys) for (x in xs) {
            val crop = Bitmap.createBitmap(source, x, y, side, side)
            val scaled = Bitmap.createScaledBitmap(crop, 224, 224, true)
            if (scaled !== crop) crop.recycle()
            val input = ByteBuffer.allocateDirect(224 * 224 * 3 * 4).order(ByteOrder.nativeOrder())
            val pixels = IntArray(224 * 224)
            scaled.getPixels(pixels, 0, 224, 0, 0, 224, 224)
            scaled.recycle()
            for (pixel in pixels) {
                input.putFloat(((pixel shr 16) and 0xFF) / 255f)
                input.putFloat(((pixel shr 8) and 0xFF) / 255f)
                input.putFloat((pixel and 0xFF) / 255f)
            }
            input.rewind()
            val output = Array(1) { FloatArray(5) }
            model.run(input, output)
            val p = output[0]
            neutral = max(neutral, p[2])
            explicit = max(explicit, p[1] + p[3])
            suggestive = max(suggestive, p[4])
        }
        return Scores(explicit, suggestive, neutral)
    }

    fun close() {
        try {
            executor.execute {
                try { interpreter?.close() } catch (_: Throwable) { }
                interpreter = null
                executor.shutdown()
            }
        } catch (_: Throwable) { }
    }

    companion object {
        private const val MODEL_FILE = "visual_nsfw_mobilenet_v2.tflite"
        private const val MODEL_URL = "https://media.githubusercontent.com/media/getknit/Knit/main/app/src/main/assets/moderation/nsfw.tflite"
        private const val MIN_MODEL_BYTES = 10L * 1024L * 1024L
        private const val MAX_MODEL_BYTES = 25L * 1024L * 1024L
        private const val MAX_DOWNLOAD_BYTES = 25L * 1024L * 1024L
    }
}
